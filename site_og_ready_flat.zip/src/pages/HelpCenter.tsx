import { useState } from "react";
import { Search, FileText, DollarSign, CreditCard, Shield, Phone, Mail, MessageCircle, Settings } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const HelpCenter = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    {
      icon: FileText,
      title: "Getting Started",
      description: "How to start free credit card processing",
      topics: ["Step-by-step onboarding guide", "Application process explained", "How long setup takes"]
    },
    {
      icon: CreditCard,
      title: "How It Works",
      description: "How free credit card processor works",
      topics: ["Surcharging vs. cash discounting", "Who pays the processing fees", "Why it's legal and compliant"]
    },
    {
      icon: DollarSign,
      title: "Pricing & Savings",
      description: "Save money on credit card fees",
      topics: ["Typical costs vs. $0 costs", "How much you can save per month/year", "No hidden fees explanation"]
    },
    {
      icon: Settings,
      title: "Equipment & POS",
      description: "POS system for free credit card processing",
      topics: ["Using your existing POS", "Getting new terminals", "Signage for compliance"]
    },
    {
      icon: Shield,
      title: "Legal & Compliance",
      description: "Is free credit card processing legal",
      topics: ["State-by-state surcharge legality map", "Required disclosures and signage", "Processor compliance standards"]
    }
  ];

  const faqs = [
    {
      question: "Is free credit card processing really free?",
      answer: "Yes! With our zero-fee processing model, you pay $0 in processing fees. Instead, a small convenience fee is automatically added to credit card transactions, which your customers pay. This fee covers the processing costs that would normally come out of your pocket."
    },
    {
      question: "Who pays the credit card fees if I don't?",
      answer: "Your customers pay a small convenience fee (typically 3-4%) when they choose to pay with a credit card. This fee covers the processing costs that credit card companies charge. Cash and debit transactions have no additional fees."
    },
    {
      question: "How does a free credit card processor make money?",
      answer: "We make money through a small portion of the convenience fee collected from credit card transactions. This transparent model allows us to offer truly free processing to businesses while maintaining our service quality."
    },
    {
      question: "Is zero-fee credit card processing legal in my state?",
      answer: "Yes, surcharging (adding a fee for credit card use) is legal in most states. We provide state-by-state compliance guidance and all required signage to ensure you're operating within local regulations."
    },
    {
      question: "Can I keep my current POS system?",
      answer: "In most cases, yes! Our solution integrates with most existing POS systems and payment terminals. Our technical team will assess your current setup during onboarding and guide you through any necessary updates."
    },
    {
      question: "Will my customers complain about the extra fee?",
      answer: "Most customers understand and accept convenience fees when they're clearly disclosed. Many businesses see little to no customer pushback, especially when they explain the savings are passed on through lower overall prices."
    },
    {
      question: "How quickly can I get set up?",
      answer: "Most businesses are up and running within 3-5 business days. This includes application approval, equipment setup (if needed), and staff training. Rush setup is available for urgent needs."
    },
    {
      question: "Are there contracts or cancellation fees?",
      answer: "No long-term contracts required! We operate on a month-to-month basis with no cancellation fees. You can discontinue service at any time with 30 days notice."
    }
  ];

  const guides = [
    {
      title: "How to Apply for Free Credit Card Processing",
      description: "Complete step-by-step guide to getting started",
      readTime: "5 min read"
    },
    {
      title: "How to Set Up Your Equipment",
      description: "Equipment installation and configuration guide",
      readTime: "10 min read"
    },
    {
      title: "How to Install POS Software for Free Processing",
      description: "Software setup and integration instructions",
      readTime: "8 min read"
    },
    {
      title: "How to Display Required Fee Signage",
      description: "Compliance signage placement and requirements",
      readTime: "3 min read"
    },
    {
      title: "How to Reconcile Daily Payouts",
      description: "Understanding your daily settlement reports",
      readTime: "6 min read"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section with Search */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Help Center – Free Credit Card Processing
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Find answers, guides, and resources to help you save money and start processing payments for free.
          </p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              type="text"
              placeholder="Search FAQs, guides, and support topics…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 py-4 text-lg bg-background border-2 focus:border-primary"
            />
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Popular Categories</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category, index) => (
              <Card 
                key={index} 
                className="hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => {
                  if (index === 0) { // Getting Started
                    window.location.href = "/help/getting-started";
                  }
                }}
              >
                <CardHeader>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <category.icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{category.title}</CardTitle>
                  </div>
                  <CardDescription className="text-base">{category.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {category.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                        {topic}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured FAQs */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
          <div className="max-w-4xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-background rounded-lg border px-6">
                  <AccordionTrigger className="text-left text-lg font-semibold hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pt-2">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Step-by-Step Guides */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Step-by-Step Guides</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {guides.map((guide, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <CardTitle className="text-lg line-clamp-2">{guide.title}</CardTitle>
                  <CardDescription>{guide.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">{guide.readTime}</span>
                    <Button variant="outline" size="sm">Read Guide</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Still Need Help CTA */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Our support team is here to help you get started with free credit card processing.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-2xl mx-auto">
            <Button size="lg" className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Call Support
            </Button>
            <Button variant="outline" size="lg" className="flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Submit a Ticket
            </Button>
            <Button variant="outline" size="lg" className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Live Chat
            </Button>
          </div>
          
          <div className="mt-12 p-8 bg-background rounded-lg border max-w-2xl mx-auto">
            <h3 className="text-xl font-semibold mb-4">Ready to Start Saving?</h3>
            <p className="text-muted-foreground mb-6">
              Join thousands of businesses already saving money with free credit card processing.
            </p>
            <Button size="lg" onClick={() => window.location.href = "/onboard"}>
              Apply Now - It's Free!
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HelpCenter;
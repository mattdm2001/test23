import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { 
  DollarSign, 
  Target, 
  BarChart3, 
  Award, 
  Zap, 
  Users, 
  Building2, 
  CreditCard, 
  Calculator, 
  Store, 
  TrendingUp, 
  Globe,
  CheckCircle,
  ArrowRight,
  Handshake
} from "lucide-react";

const Partner = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    phone: "",
    role: "",
    referrals: "",
    currentlySellingMS: ""
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Partner application submitted:", formData);
  };

  const benefits = [
    {
      icon: DollarSign,
      title: "Earn Recurring Commission",
      description: "Get paid monthly for every client you refer"
    },
    {
      icon: Target,
      title: "Easiest Pitch in Payments",
      description: "Offer a solution that actually saves business owners money"
    },
    {
      icon: BarChart3,
      title: "Real-Time Reporting",
      description: "Access your client stats and earnings via our partner dashboard"
    },
    {
      icon: Award,
      title: "White-Label Friendly",
      description: "Add your logo and brand if preferred"
    },
    {
      icon: Zap,
      title: "Fast Onboarding",
      description: "Approvals and installs in 24–48 hours"
    }
  ];

  const partnerTypes = [
    { icon: Users, label: "ISOs & Merchant Services Agents" },
    { icon: Building2, label: "Business Loan Brokers" },
    { icon: CreditCard, label: "SaaS / POS Companies" },
    { icon: Calculator, label: "Commercial Consultants & Bookkeepers" },
    { icon: Store, label: "Franchise Vendors" },
    { icon: TrendingUp, label: "Affiliate Marketers" }
  ];

  const steps = [
    {
      number: "1",
      title: "Apply Online",
      description: "We'll get you approved within 1 business day"
    },
    {
      number: "2",
      title: "Get Your Portal",
      description: "Track leads, earnings, and support tickets"
    },
    {
      number: "3",
      title: "Start Referring",
      description: "Share your link or refer merchants directly"
    }
  ];

  const faqs = [
    {
      question: "What's the commission structure?",
      answer: "We offer competitive recurring commissions based on merchant volume and retention. Specific rates are provided during the application process."
    },
    {
      question: "How often do I get paid?",
      answer: "Commission payments are made monthly, typically within the first week of each month for the previous month's activity."
    },
    {
      question: "Can I white-label this?",
      answer: "Yes! We offer white-label solutions where you can add your branding and present the service as your own offering."
    },
    {
      question: "Do you support integrations with POS software?",
      answer: "We work with major POS providers and can integrate with most existing systems to ensure a seamless transition."
    },
    {
      question: "Do you handle support & onboarding?",
      answer: "Absolutely. We provide full support for merchant onboarding, technical setup, and ongoing customer service."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-primary bg-clip-text text-transparent">
              Help Businesses Eliminate Fees — and Earn Recurring Income Doing It
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Whether you're an ISO, consultant, or tech reseller, our zero-cost processing model is the easiest pitch in the industry.
            </p>
            <Button size="xl" variant="cta" className="mb-8" onClick={() => document.getElementById('application')?.scrollIntoView({ behavior: 'smooth' })}>
              Apply to Partner
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <div className="flex justify-center">
              <div className="w-32 h-32 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                <Handshake className="h-16 w-16 text-primary-foreground" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Partner With Us?</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover:shadow-card transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                    <benefit.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{benefit.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Types Section */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Who Is This For?</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {partnerTypes.map((type, index) => (
              <Badge key={index} variant="secondary" className="p-4 text-base justify-start gap-3 hover:bg-primary hover:text-primary-foreground transition-colors cursor-pointer">
                <type.icon className="h-5 w-5" />
                {type.label}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Start Referring in 3 Simple Steps</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6 shadow-glow">
                  <span className="text-2xl font-bold text-primary-foreground">{step.number}</span>
                </div>
                <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Application Form */}
      <section id="application" className="py-16 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Partner Application</h2>
            <p className="text-lg text-muted-foreground">Ready to start earning? Fill out the form below to get started.</p>
          </div>
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Application Form</CardTitle>
              <CardDescription>Please provide the following information to begin the partnership process.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input 
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input 
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="company">Company Name</Label>
                    <Input 
                      id="company"
                      value={formData.company}
                      onChange={(e) => handleInputChange('company', e.target.value)}
                      placeholder="Your company name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input 
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="(555) 123-4567"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="role">Role/Title</Label>
                  <Input 
                    id="role"
                    value={formData.role}
                    onChange={(e) => handleInputChange('role', e.target.value)}
                    placeholder="e.g., Sales Agent, Business Consultant"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="referrals">Estimated Monthly Referrals</Label>
                  <Select onValueChange={(value) => handleInputChange('referrals', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select expected volume" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-5">1-5 referrals</SelectItem>
                      <SelectItem value="6-15">6-15 referrals</SelectItem>
                      <SelectItem value="16-30">16-30 referrals</SelectItem>
                      <SelectItem value="30+">30+ referrals</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currentlySellingMS">Do you currently sell merchant services?</Label>
                  <Select onValueChange={(value) => handleInputChange('currentlySellingMS', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select an option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" size="lg" className="w-full" variant="cta">
                  Submit Application
                  <CheckCircle className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          </div>
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg font-semibold">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="py-16 px-4 bg-gradient-primary text-primary-foreground">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to start offering truly free credit card processing?
          </h2>
          <Button 
            size="xl" 
            variant="secondary" 
            onClick={() => document.getElementById('application')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Become a Partner
            <Globe className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Sticky CTA Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-primary text-primary-foreground p-4 shadow-elegant z-50 md:hidden">
        <div className="flex items-center justify-between max-w-sm mx-auto">
          <span className="font-semibold">Join Our Partner Program</span>
          <Button 
            size="sm" 
            variant="secondary"
            onClick={() => document.getElementById('application')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Apply Now
          </Button>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Partner;
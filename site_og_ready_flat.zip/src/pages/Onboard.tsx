import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Upload, Shield, ArrowRight, CheckCircle, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { SignatureCanvas } from "@/components/SignatureCanvas";
import { validateStep, getFieldDisplayName } from "@/utils/formValidation";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Onboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    // Step 1: Business Basics
    businessName: "",
    dba: "",
    businessAddress: "",
    businessPhone: "",
    website: "",
    ein: "",
    
    // Step 2: Ownership Information
    ownerName: "",
    dateOfBirth: "",
    email: "",
    mobilePhone: "",
    ownershipPercent: "",
    homeAddress: "",
    ssn: "",
    
    // Step 3: Business Type & Processing
    businessType: "",
    monthlyVolume: "",
    avgTicketSize: "",
    monthlyTransactions: "",
    currentProcessor: "",
    acceptsTips: "",
    physicalLocation: "",
    
    // Step 4: Banking Info
    bankName: "",
    routingNumber: "",
    accountNumber: "",
    voidedCheck: null,
    
    // Step 5: Supporting Documents
    driversLicense: null,
    businessLicense: null,
    processingStatement: null,
    
    // Step 6: Equipment & Setup
    needsEquipment: "",
    terminalType: "",
    currentPOS: "",
    needsSignage: "",
    
    // Step 7: Certification
    certified: false,
    signature: "",
  });

  const totalSteps = 7;
  const progressPercentage = (currentStep / totalSteps) * 100;

  const handleInputChange = (field: string, value: any) => {
    console.log('Input change:', field, 'Value:', value);
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    // Validate current step before proceeding
    const validation = validateStep(currentStep, formData);
    
    if (!validation.isValid) {
      const missingFieldNames = validation.missingFields.map(getFieldDisplayName);
      toast({
        title: "Please complete all required fields",
        description: `Missing: ${missingFieldNames.join(", ")}`,
        variant: "destructive",
      });
      return;
    }

    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const uploadFileToStorage = async (file: File, bucket: string, folder: string): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `${folder}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from(bucket)
        .upload(filePath, file);

      if (uploadError) {
        console.error('Upload error:', uploadError);
        return null;
      }

      const { data } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('File upload failed:', error);
      return null;
    }
  };

  const uploadSignatureToStorage = async (signatureDataUrl: string): Promise<string | null> => {
    try {
      // Convert data URL to blob
      const response = await fetch(signatureDataUrl);
      const blob = await response.blob();
      
      const fileName = `signature_${Date.now()}.png`;
      const filePath = `signatures/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('application-documents')
        .upload(filePath, blob, {
          contentType: 'image/png',
        });

      if (uploadError) {
        console.error('Signature upload error:', uploadError);
        return null;
      }

      const { data } = supabase.storage
        .from('application-documents')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Signature upload failed:', error);
      return null;
    }
  };

  const handleSubmit = async () => {
    console.log('Submit button clicked, current step:', currentStep);
    console.log('Form data at submission:', formData);
    
    // Final validation
    const validation = validateStep(7, formData);
    console.log('Validation result:', validation);
    
    if (!validation.isValid || !formData.certified) {
      console.log('Validation failed:', validation);
      toast({
        title: "Please complete all required fields",
        description: "Certification and signature are required to submit.",
        variant: "destructive",
      });
      return;
    }

    try {
      toast({
        title: "Submitting application...",
        description: "Please wait while we process your information.",
      });

      // Upload files
      let driversLicenseUrl = null;
      let businessLicenseUrl = null;
      let processingStatementUrl = null;
      let signatureUrl = null;

      if (formData.driversLicense) {
        driversLicenseUrl = await uploadFileToStorage(formData.driversLicense, 'application-documents', 'drivers-licenses');
      }

      if (formData.businessLicense) {
        businessLicenseUrl = await uploadFileToStorage(formData.businessLicense, 'application-documents', 'business-licenses');
      }

      if (formData.processingStatement) {
        processingStatementUrl = await uploadFileToStorage(formData.processingStatement, 'application-documents', 'processing-statements');
      }

      if (formData.signature) {
        signatureUrl = await uploadSignatureToStorage(formData.signature);
      }

      // Save to database
      const { error } = await supabase
        .from('onboarding_applications')
        .insert({
          business_name: formData.businessName,
          dba: formData.dba,
          business_address: formData.businessAddress,
          business_phone: formData.businessPhone,
          website: formData.website,
          ein: formData.ein,
          owner_name: formData.ownerName,
          date_of_birth: formData.dateOfBirth,
          email: formData.email,
          mobile_phone: formData.mobilePhone,
          ownership_percent: formData.ownershipPercent,
          home_address: formData.homeAddress,
          ssn: formData.ssn,
          business_type: formData.businessType,
          monthly_volume: formData.monthlyVolume,
          avg_ticket_size: formData.avgTicketSize,
          monthly_transactions: formData.monthlyTransactions,
          current_processor: formData.currentProcessor,
          accepts_tips: formData.acceptsTips,
          physical_location: formData.physicalLocation,
          bank_name: formData.bankName,
          routing_number: formData.routingNumber,
          account_number: formData.accountNumber,
          drivers_license_url: driversLicenseUrl,
          business_license_url: businessLicenseUrl,
          processing_statement_url: processingStatementUrl,
          needs_equipment: formData.needsEquipment,
          terminal_type: formData.terminalType,
          current_pos: formData.currentPOS,
          needs_signage: formData.needsSignage,
          certified: formData.certified,
          signature_url: signatureUrl,
          submitted_at: new Date().toISOString(),
        });

      if (error) {
        console.error('Database error:', error);
        toast({
          title: "Submission failed",
          description: "There was an error submitting your application. Please try again.",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Application submitted successfully!",
        description: "A specialist will contact you within 1 business day.",
      });

      setCurrentStep(totalSteps + 1); // Show confirmation
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your application. Please try again.",
        variant: "destructive",
      });
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Let's start with your business basics</h2>
              <p className="text-muted-foreground">Tell us about your business and what you do</p>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label htmlFor="businessName">Business Name *</Label>
                <Input
                  id="businessName"
                  value={formData.businessName}
                  onChange={(e) => handleInputChange("businessName", e.target.value)}
                  placeholder="Enter your legal business name"
                />
              </div>
              
              <div>
                <Label htmlFor="dba">DBA (Doing Business As)</Label>
                <Input
                  id="dba"
                  value={formData.dba}
                  onChange={(e) => handleInputChange("dba", e.target.value)}
                  placeholder="If different from business name (optional)"
                />
              </div>
              
              <div>
                <Label htmlFor="businessAddress">Business Address *</Label>
                <Textarea
                  id="businessAddress"
                  value={formData.businessAddress}
                  onChange={(e) => handleInputChange("businessAddress", e.target.value)}
                  placeholder="Street address, city, state, ZIP"
                  rows={3}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="businessPhone">Business Phone *</Label>
                  <Input
                    id="businessPhone"
                    value={formData.businessPhone}
                    onChange={(e) => handleInputChange("businessPhone", e.target.value)}
                    placeholder="(555) 123-4567"
                  />
                </div>
                
                <div>
                  <Label htmlFor="website">Website / Social Media</Label>
                  <Input
                    id="website"
                    value={formData.website}
                    onChange={(e) => handleInputChange("website", e.target.value)}
                    placeholder="www.yourbusiness.com"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="ein">EIN or SSN *</Label>
                <Input
                  id="ein"
                  value={formData.ein}
                  onChange={(e) => handleInputChange("ein", e.target.value)}
                  placeholder="12-3456789 or 123-45-6789"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Tell us about the business owner</h2>
              <p className="text-muted-foreground">We need to verify the identity of the business owner</p>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg mb-6">
              <div className="flex items-center gap-2 text-blue-800">
                <Shield className="w-5 h-5" />
                <span className="text-sm font-medium">Secure & encrypted. Required for compliance & verification.</span>
              </div>
            </div>
            
            <div className="grid gap-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ownerName">Owner Full Name *</Label>
                  <Input
                    id="ownerName"
                    value={formData.ownerName}
                    onChange={(e) => handleInputChange("ownerName", e.target.value)}
                    placeholder="First Last"
                  />
                </div>
                
                <div>
                  <Label htmlFor="dateOfBirth">Date of Birth *</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="owner@business.com"
                  />
                </div>
                
                <div>
                  <Label htmlFor="mobilePhone">Mobile Phone *</Label>
                  <Input
                    id="mobilePhone"
                    value={formData.mobilePhone}
                    onChange={(e) => handleInputChange("mobilePhone", e.target.value)}
                    placeholder="(555) 123-4567"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ownershipPercent">% Ownership *</Label>
                  <Input
                    id="ownershipPercent"
                    value={formData.ownershipPercent}
                    onChange={(e) => handleInputChange("ownershipPercent", e.target.value)}
                    placeholder="100"
                  />
                </div>
                
                <div>
                  <Label htmlFor="ssn">SSN (Last 4 digits) *</Label>
                  <Input
                    id="ssn"
                    value={formData.ssn}
                    onChange={(e) => handleInputChange("ssn", e.target.value)}
                    placeholder="1234"
                    maxLength={4}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="homeAddress">Home Address *</Label>
                <Textarea
                  id="homeAddress"
                  value={formData.homeAddress}
                  onChange={(e) => handleInputChange("homeAddress", e.target.value)}
                  placeholder="Street address, city, state, ZIP"
                  rows={3}
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">What type of business do you operate?</h2>
              <p className="text-muted-foreground">Help us understand your processing needs</p>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label htmlFor="businessType">Business Type *</Label>
                <Select value={formData.businessType} onValueChange={(value) => handleInputChange("businessType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your business type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="retail">Retail Store</SelectItem>
                    <SelectItem value="restaurant">Restaurant / Food Service</SelectItem>
                    <SelectItem value="professional">Professional Services</SelectItem>
                    <SelectItem value="ecommerce">E-commerce / Online</SelectItem>
                    <SelectItem value="automotive">Automotive</SelectItem>
                    <SelectItem value="healthcare">Healthcare</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="monthlyVolume">Monthly Credit Card Volume *</Label>
                  <Select value={formData.monthlyVolume} onValueChange={(value) => handleInputChange("monthlyVolume", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select volume range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0-5k">$0 - $5,000</SelectItem>
                      <SelectItem value="5k-15k">$5,000 - $15,000</SelectItem>
                      <SelectItem value="15k-50k">$15,000 - $50,000</SelectItem>
                      <SelectItem value="50k-100k">$50,000 - $100,000</SelectItem>
                      <SelectItem value="100k+">$100,000+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="avgTicketSize">Average Ticket Size *</Label>
                  <Input
                    id="avgTicketSize"
                    value={formData.avgTicketSize}
                    onChange={(e) => handleInputChange("avgTicketSize", e.target.value)}
                    placeholder="$25.00"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="monthlyTransactions">Monthly Transactions *</Label>
                  <Input
                    id="monthlyTransactions"
                    value={formData.monthlyTransactions}
                    onChange={(e) => handleInputChange("monthlyTransactions", e.target.value)}
                    placeholder="150"
                  />
                </div>
                
                <div>
                  <Label htmlFor="currentProcessor">Current Processor</Label>
                  <Select value={formData.currentProcessor} onValueChange={(value) => handleInputChange("currentProcessor", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select current processor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="square">Square</SelectItem>
                      <SelectItem value="clover">Clover</SelectItem>
                      <SelectItem value="stripe">Stripe</SelectItem>
                      <SelectItem value="paypal">PayPal</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                      <SelectItem value="none">No current processor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Do you accept tips? *</Label>
                  <Select value={formData.acceptsTips} onValueChange={(value) => handleInputChange("acceptsTips", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label>Physical location? *</Label>
                  <Select value={formData.physicalLocation} onValueChange={(value) => handleInputChange("physicalLocation", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="yes">Yes</SelectItem>
                      <SelectItem value="no">No - Online only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Banking information</h2>
              <p className="text-muted-foreground">Where should we deposit your payments?</p>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg mb-6">
              <div className="flex items-center gap-2 text-blue-800">
                <Shield className="w-5 h-5" />
                <span className="text-sm font-medium">Bank details are encrypted and secured. Required for payment deposits.</span>
              </div>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label htmlFor="bankName">Bank Name *</Label>
                <Input
                  id="bankName"
                  value={formData.bankName}
                  onChange={(e) => handleInputChange("bankName", e.target.value)}
                  placeholder="Chase, Bank of America, etc."
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="routingNumber">Routing Number *</Label>
                  <Input
                    id="routingNumber"
                    value={formData.routingNumber}
                    onChange={(e) => handleInputChange("routingNumber", e.target.value)}
                    placeholder="123456789"
                  />
                </div>
                
                <div>
                  <Label htmlFor="accountNumber">Account Number *</Label>
                  <Input
                    id="accountNumber"
                    value={formData.accountNumber}
                    onChange={(e) => handleInputChange("accountNumber", e.target.value)}
                    placeholder="1234567890"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="voidedCheck">Upload Voided Check or Bank Letter *</Label>
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                  onClick={() => document.getElementById('voidedCheck')?.click()}
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600 mb-2">
                    {formData.voidedCheck ? formData.voidedCheck.name : "Drag and drop files here, or click to browse"}
                  </p>
                  <p className="text-xs text-gray-400">Accepts PNG, PDF, JPEG files</p>
                  <input
                    id="voidedCheck"
                    type="file"
                    className="hidden"
                    accept=".png,.pdf,.jpeg,.jpg"
                    onChange={(e) => handleInputChange("voidedCheck", e.target.files?.[0])}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Supporting documents</h2>
              <p className="text-muted-foreground">Help us verify your identity and business</p>
            </div>
            
            <div className="grid gap-6">
              <div>
                <Label>Driver's License (Front + Back) *</Label>
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                  onClick={() => document.getElementById('driversLicense')?.click()}
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600 mb-2">
                    {formData.driversLicense ? formData.driversLicense.name : "Upload both sides of your driver's license"}
                  </p>
                  <p className="text-xs text-gray-400">Accepts PNG, PDF, JPEG files</p>
                  <input
                    id="driversLicense"
                    type="file"
                    className="hidden"
                    accept=".png,.pdf,.jpeg,.jpg"
                    onChange={(e) => handleInputChange("driversLicense", e.target.files?.[0])}
                  />
                </div>
              </div>
              
              <div>
                <Label>Business License or Articles of Incorporation</Label>
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                  onClick={() => document.getElementById('businessLicense')?.click()}
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600 mb-2">
                    {formData.businessLicense ? formData.businessLicense.name : "Optional but recommended"}
                  </p>
                  <p className="text-xs text-gray-400">Accepts PNG, PDF, JPEG files</p>
                  <input
                    id="businessLicense"
                    type="file"
                    className="hidden"
                    accept=".png,.pdf,.jpeg,.jpg"
                    onChange={(e) => handleInputChange("businessLicense", e.target.files?.[0])}
                  />
                </div>
              </div>
              
              <div>
                <Label>Most Recent Processing Statement</Label>
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
                  onClick={() => document.getElementById('processingStatement')?.click()}
                >
                  <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-sm text-gray-600 mb-2">
                    {formData.processingStatement ? formData.processingStatement.name : "Optional but encouraged - helps us understand your current costs"}
                  </p>
                  <p className="text-xs text-gray-400">Accepts PNG, PDF, JPEG files</p>
                  <input
                    id="processingStatement"
                    type="file"
                    className="hidden"
                    accept=".png,.pdf,.jpeg,.jpg"
                    onChange={(e) => handleInputChange("processingStatement", e.target.files?.[0])}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Equipment & setup preferences</h2>
              <p className="text-muted-foreground">Let us know what you need to get started</p>
            </div>
            
            <div className="grid gap-4">
              <div>
                <Label>Do you need equipment? *</Label>
                <Select value={formData.needsEquipment} onValueChange={(value) => handleInputChange("needsEquipment", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Yes, I need new equipment</SelectItem>
                    <SelectItem value="no">No, I have compatible equipment</SelectItem>
                    <SelectItem value="unsure">I'm not sure</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {formData.needsEquipment === "yes" && (
                <div>
                  <Label>Terminal Type Preference</Label>
                  <Select value={formData.terminalType} onValueChange={(value) => handleInputChange("terminalType", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select terminal type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="countertop">Countertop Terminal</SelectItem>
                      <SelectItem value="mobile">Mobile Terminal</SelectItem>
                      <SelectItem value="virtual">Virtual Terminal (software only)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              <div>
                <Label>Current POS Brand</Label>
                <Input
                  value={formData.currentPOS}
                  onChange={(e) => handleInputChange("currentPOS", e.target.value)}
                  placeholder="Square, Clover, Toast, etc. (optional)"
                />
              </div>
              
              <div>
                <Label>Do you need signage for fee disclosure? *</Label>
                <Select value={formData.needsSignage} onValueChange={(value) => handleInputChange("needsSignage", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">Yes, please provide signage</SelectItem>
                    <SelectItem value="no">No, I'll handle my own signage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 7:
        return (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">Final step: Certification & signature</h2>
              <p className="text-muted-foreground">Review and certify your application</p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <h3 className="font-semibold mb-4">Application Summary</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>Business:</strong> {formData.businessName}
                </div>
                <div>
                  <strong>Owner:</strong> {formData.ownerName}
                </div>
                <div>
                  <strong>Business Type:</strong> {formData.businessType}
                </div>
                <div>
                  <strong>Monthly Volume:</strong> {formData.monthlyVolume}
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-2">
                <Checkbox
                  id="certification"
                  checked={formData.certified}
                  onCheckedChange={(checked) => handleInputChange("certified", checked)}
                />
                <Label htmlFor="certification" className="text-sm leading-relaxed">
                  I certify that the information provided is true and accurate to the best of my knowledge. 
                  I understand that this application will be reviewed and that additional documentation may be required.
                </Label>
              </div>
              
              <SignatureCanvas
                onSignatureChange={(signature) => handleInputChange("signature", signature)}
                value={formData.signature}
              />
              
              <div>
                <Label>Date</Label>
                <Input
                  value={new Date().toLocaleDateString()}
                  disabled
                  className="bg-gray-50"
                />
              </div>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center space-y-6">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">Application Submitted Successfully!</h2>
              <p className="text-muted-foreground mb-6">
                Thank you! Your application has been submitted. A specialist will contact you within 1 business day.
              </p>
            </div>
            
            <div className="grid gap-4 max-w-md mx-auto">
              <Button onClick={() => navigate("/")} variant="outline">
                Return to Homepage
              </Button>
              <Button 
                variant="default"
                onClick={() => window.open('https://calendly.com/submissions-remeliofinancing/30min', '_blank')}
              >
                Schedule a Call
              </Button>
            </div>
            
            <div className="flex items-center justify-center gap-4 pt-6 border-t">
              <Shield className="w-5 h-5 text-green-600" />
              <span className="text-sm text-muted-foreground">PCI Compliant • SSL Secured • Encrypted Data</span>
            </div>
          </div>
        );
    }
  };

  if (currentStep > totalSteps) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="shadow-lg">
            <CardContent className="p-8">
              {renderStep()}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Let's Get You Set Up for Free Credit Card Processing</h1>
          <p className="text-muted-foreground">No fees. No contracts. No risk. Just more money in your pocket.</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-muted-foreground mb-2">
            <span>Step {currentStep} of {totalSteps}</span>
            <span>{Math.round(progressPercentage)}% Complete</span>
          </div>
          <Progress value={progressPercentage} className="h-2" />
        </div>

        {/* Form Card */}
        <Card className="shadow-lg">
          <CardContent className="p-8">
            {renderStep()}
            
            <Separator className="my-8" />
            
            {/* Navigation Buttons */}
            <div className="flex justify-end">
              {currentStep === totalSteps ? (
                <Button
                  onClick={handleSubmit}
                  disabled={!formData.certified || !formData.signature}
                  className="flex items-center gap-2"
                  variant="cta"
                  size="lg"
                >
                  Submit Application
                  <CheckCircle className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleNext}
                  className="flex items-center gap-2"
                  variant="cta"
                  size="lg"
                >
                  Continue
                  <ArrowRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Trust Badges */}
        <div className="flex items-center justify-center gap-4 mt-8 text-sm text-muted-foreground">
          <Shield className="w-4 h-4" />
          <span>PCI Compliant</span>
          <span>•</span>
          <span>SSL Secured</span>
          <span>•</span>
          <span>Encrypted Data</span>
        </div>
      </div>
    </div>
  );
};

export default Onboard;
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CheckCircle, X, Calculator } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Pricing = () => {
  const navigate = useNavigate();
  const [monthlyVolume, setMonthlyVolume] = useState("");
  const [calculatedSavings, setCalculatedSavings] = useState(0);

  const traditionalCosts = [
    { volume: "$5,000", fee: "$137.50", monthly: "$137.50", annual: "$1,650" },
    { volume: "$10,000", fee: "$275.00", monthly: "$275.00", annual: "$3,300" },
    { volume: "$25,000", fee: "$687.50", monthly: "$687.50", annual: "$8,250" },
  ];

  const calculateSavings = () => {
    const volume = parseFloat(monthlyVolume.replace(/[$,]/g, ""));
    if (volume > 0) {
      const annualSavings = (volume * 0.0275 * 12);
      setCalculatedSavings(annualSavings);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-section">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Free Credit Card Processing — Pay $0 in Fees. Seriously.
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Stop losing thousands to payment processing fees. Keep 100% of your revenue with our zero-cost solution.
            </p>
          </div>
        </section>

        {/* Section 1 - What You Used To Pay */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Traditional Processors Cost You Money Every Swipe
              </h2>
              <p className="text-lg text-muted-foreground">
                See how much you're actually paying in hidden fees
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <Card className="overflow-hidden shadow-elegant">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-destructive/10">
                      <TableHead className="text-center font-semibold">Monthly Sales Volume</TableHead>
                      <TableHead className="text-center font-semibold">Avg. Fee (2.75%)</TableHead>
                      <TableHead className="text-center font-semibold">Monthly Cost</TableHead>
                      <TableHead className="text-center font-semibold">Annual Cost</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {traditionalCosts.map((row, index) => (
                      <TableRow key={index}>
                        <TableCell className="text-center font-medium">{row.volume}</TableCell>
                        <TableCell className="text-center text-destructive font-semibold">{row.fee}</TableCell>
                        <TableCell className="text-center text-destructive font-semibold">{row.monthly}</TableCell>
                        <TableCell className="text-center text-destructive font-bold text-lg">{row.annual}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Card>

              <div className="text-center mt-8">
                <div className="inline-flex items-center gap-2 bg-destructive/10 text-destructive px-6 py-3 rounded-lg">
                  <X className="w-5 h-5" />
                  <span className="font-semibold text-lg">
                    That's thousands in fees — just for accepting cards.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2 - What You Pay With Us */}
        <section className="py-16 bg-gradient-section">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                With FreeCreditCardProcessor.com — You Pay $0
              </h2>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="grid md:grid-cols-2 gap-8 mb-8">
                <Card className="p-8 shadow-elegant bg-success/5 border-success/20">
                  <h3 className="text-2xl font-bold text-foreground mb-6">What You Don't Pay</h3>
                  <div className="space-y-4">
                    {[
                      "No setup fees",
                      "No monthly fees", 
                      "No transaction fees",
                      "No contracts or cancellation penalties"
                    ].map((item, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-success" />
                        <span className="text-foreground font-medium">{item}</span>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card className="p-8 shadow-elegant bg-gradient-primary text-primary-foreground">
                  <h3 className="text-2xl font-bold mb-6">What You Get</h3>
                  <div className="space-y-4">
                    {[
                      "You keep 100% of your sales revenue",
                      "Equipment available — or keep your existing POS",
                      "Next-day payouts",
                      "24/7 customer support"
                    ].map((item, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-primary-glow" />
                        <span className="font-medium">{item}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>

              <div className="text-center">
                <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
                  <strong>Note:</strong> Processing fees are passed to the cardholder via a small checkout adjustment — 
                  fully compliant & legal in all supported states.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3 - What's the Catch */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                What's the Catch?
              </h2>
              <p className="text-2xl text-muted-foreground font-medium">
                There Isn't One. It's Just a Smarter Model.
              </p>
            </div>

            <div className="max-w-4xl mx-auto">
              <div className="grid md:grid-cols-3 gap-8">
                <Card className="p-6 text-center shadow-card">
                  <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <X className="w-8 h-8 text-destructive" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">Traditional Model</h3>
                  <p className="text-muted-foreground">
                    Traditional processors make you eat the cost of every transaction
                  </p>
                </Card>

                <Card className="p-6 text-center shadow-card bg-primary/5 border-primary/20">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">Our Model</h3>
                  <p className="text-muted-foreground">
                    We route you to a partner who lets customers cover the fee
                  </p>
                </Card>

                <Card className="p-6 text-center shadow-card">
                  <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-success" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3">Your Result</h3>
                  <p className="text-muted-foreground">
                    You pay nothing, keep more, and grow faster
                  </p>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Savings Calculator */}
        <section className="py-16 bg-gradient-section">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <div className="flex items-center justify-center gap-3 mb-6">
                <Calculator className="w-8 h-8 text-primary" />
                <h2 className="text-3xl font-bold text-foreground">
                  How Much Could You Save?
                </h2>
              </div>
              
              <Card className="p-8 shadow-elegant">
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Monthly Card Sales Volume
                    </label>
                    <Input
                      type="text"
                      placeholder="e.g., $10,000"
                      value={monthlyVolume}
                      onChange={(e) => setMonthlyVolume(e.target.value)}
                      className="text-center text-lg"
                    />
                  </div>
                  
                  <Button 
                    onClick={calculateSavings}
                    className="w-full"
                    size="lg"
                  >
                    Calculate My Savings
                  </Button>
                  
                  {calculatedSavings > 0 && (
                    <div className="bg-success/10 border border-success/20 rounded-lg p-6 text-center space-y-4">
                      <p className="text-lg text-foreground mb-2">
                        You'd save approximately:
                      </p>
                      <p className="text-4xl font-bold text-success">
                        ${calculatedSavings.toLocaleString()} per year
                      </p>
                      <Button 
                        onClick={() => navigate('/onboard')}
                        variant="cta"
                        size="lg"
                        className="w-full"
                      >
                        Start Saving ${calculatedSavings.toLocaleString()} Today
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            </div>
          </div>
        </section>

        {/* Sticky CTA Strip */}
        <div className="fixed bottom-0 left-0 right-0 bg-gradient-primary text-primary-foreground shadow-glow z-50">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-lg">
                Still paying to get paid?
              </span>
              <Button 
                onClick={() => navigate('/onboard')}
                variant="outline" 
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                Start Free Processing Today
              </Button>
            </div>
          </div>
        </div>
      </main>
      
      <div className="pb-20">
        <Footer />
      </div>
    </div>
  );
};

export default Pricing;
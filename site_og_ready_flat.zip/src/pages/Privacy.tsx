import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";

const Privacy = () => {
  const sections = [
    { id: "introduction", title: "Introduction" },
    { id: "information-collected", title: "What Information We Collect" },
    { id: "how-we-use", title: "How We Use Your Information" },
    { id: "sharing", title: "Sharing Your Information" },
    { id: "cookies", title: "Cookies & Tracking" },
    { id: "security", title: "Data Security" },
    { id: "rights", title: "Your Rights & Choices" },
    { id: "third-party", title: "Third-Party Links" },
    { id: "updates", title: "Updates to This Policy" },
    { id: "contact", title: "Contact Us" }
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-8 bg-gradient-subtle">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Privacy Policy
            </h1>
            <p className="text-lg text-muted-foreground">
              Last Updated: July 2025
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Table of Contents */}
          <Card className="p-6 mb-8 bg-card border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Table of Contents</h2>
            <nav className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {sections.map((section, index) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className="text-left text-primary hover:text-primary/80 transition-colors text-sm py-1"
                >
                  {index + 1}. {section.title}
                </button>
              ))}
            </nav>
          </Card>

          {/* Content Sections */}
          <div className="prose prose-gray max-w-none">
            {/* Introduction */}
            <section id="introduction" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                1. Introduction
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <h3 className="text-lg font-medium text-foreground mb-3">
                  Welcome to FreeCreditCardProcessor.com
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  This Privacy Policy outlines how we collect, use, share, and safeguard your personal information. By visiting our website, submitting a form, or using our services, you agree to the terms of this policy.
                </p>
              </div>
            </section>

            {/* What Information We Collect */}
            <section id="information-collected" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                2. What Information We Collect
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">We collect the following types of information:</p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Name, phone number, email address
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Business information (e.g., business name, EIN, processing volume)
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Device data and IP address
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Interaction data (e.g., form submissions, chatbot messages)
                  </li>
                </ul>
              </div>
            </section>

            {/* How We Use Your Information */}
            <section id="how-we-use" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                3. How We Use Your Information
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">We use your information to:</p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Evaluate your eligibility for merchant services
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Process your application
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Communicate offers, updates, or support
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Improve our website experience
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Comply with legal or regulatory obligations
                  </li>
                </ul>
              </div>
            </section>

            {/* Sharing Your Information */}
            <section id="sharing" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                4. Sharing Your Information
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">We may share your information with:</p>
                <ul className="space-y-2 text-muted-foreground mb-4">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Verified merchant service providers or lenders to process your application
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    CRM, analytics, or marketing platforms (e.g., HubSpot, Google Analytics)
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Legal or regulatory authorities as required
                  </li>
                </ul>
                <p className="text-foreground font-medium">
                  We do not sell your personal information.
                </p>
              </div>
            </section>

            {/* Cookies & Tracking */}
            <section id="cookies" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                5. Cookies & Tracking
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">We use cookies and similar tracking tools to:</p>
                <ul className="space-y-2 text-muted-foreground mb-4">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Analyze site usage
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Improve performance
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Provide personalized experiences
                  </li>
                </ul>
                <p className="text-muted-foreground">
                  Users can adjust cookie settings in their browser at any time.
                </p>
              </div>
            </section>

            {/* Data Security */}
            <section id="security" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                6. Data Security
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground">
                  We implement physical, administrative, and technical safeguards to protect your information. All sensitive form data is encrypted during transmission.
                </p>
              </div>
            </section>

            {/* Your Rights & Choices */}
            <section id="rights" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                7. Your Rights & Choices
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    You can request to access, update, or delete your personal data
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    You may unsubscribe from email marketing at any time
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    CCPA and GDPR-related requests can be submitted via our contact form
                  </li>
                </ul>
              </div>
            </section>

            {/* Third-Party Links */}
            <section id="third-party" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                8. Third-Party Links
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground">
                  Our website may contain links to third-party websites. We are not responsible for their content or privacy practices.
                </p>
              </div>
            </section>

            {/* Updates to This Policy */}
            <section id="updates" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                9. Updates to This Policy
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground">
                  We may update this Privacy Policy periodically. The latest version will always be posted here with a modified "Last Updated" date.
                </p>
              </div>
            </section>

            {/* Contact Us */}
            <section id="contact" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                10. Contact Us
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">Have questions about your privacy?</p>
                <div className="space-y-2 text-muted-foreground">
                  <p className="flex items-center gap-2">
                    <span className="text-primary">📧</span>
                    Email: support@freecreditcardprocessor.com
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="text-primary">📞</span>
                    Phone: (888) XXX-XXXX
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Privacy;
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { 
  Users, 
  Target, 
  Zap, 
  Heart, 
  TrendingUp, 
  Shield,
  Building2,
  MapPin,
  Clock,
  DollarSign,
  Briefcase,
  Send,
  CheckCircle,
  ArrowRight,
  Star
} from "lucide-react";

const Careers = () => {
  const navigate = useNavigate();
  const [applicationData, setApplicationData] = useState({
    name: "",
    email: "",
    phone: "",
    position: "",
    experience: "",
    coverLetter: "",
    resumeFile: null as File | null
  });

  const handleInputChange = (field: string, value: string) => {
    setApplicationData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setApplicationData(prev => ({ ...prev, resumeFile: file }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Job application submitted:", applicationData);
  };

  const values = [
    {
      icon: Users,
      title: "People First",
      description: "We believe our team is our greatest asset and prioritize their growth and wellbeing."
    },
    {
      icon: Target,
      title: "Mission Driven",
      description: "We're passionate about helping businesses save money and grow with transparent pricing."
    },
    {
      icon: Zap,
      title: "Innovation",
      description: "We constantly push boundaries to create better solutions for merchants and partners."
    },
    {
      icon: Heart,
      title: "Integrity",
      description: "We operate with transparency, honesty, and ethical business practices in everything we do."
    }
  ];

  const benefits = [
    {
      icon: Heart,
      title: "Comprehensive Health Insurance",
      description: "Medical, dental, and vision coverage for you and your family"
    },
    {
      icon: TrendingUp,
      title: "Growth Opportunities",
      description: "Clear career progression paths and professional development support"
    },
    {
      icon: Clock,
      title: "Flexible Work Arrangements",
      description: "Remote work options and flexible scheduling to maintain work-life balance"
    },
    {
      icon: DollarSign,
      title: "Competitive Compensation",
      description: "Market-rate salaries plus performance bonuses and equity opportunities"
    },
    {
      icon: Shield,
      title: "Retirement Benefits",
      description: "401(k) with company matching and comprehensive financial planning"
    },
    {
      icon: Star,
      title: "Unlimited PTO",
      description: "Take the time you need to recharge and maintain peak performance"
    }
  ];

  const openPositions = [
    {
      title: "Senior Sales Executive",
      department: "Sales",
      location: "Remote",
      type: "Full-time",
      description: "Drive new business acquisition and manage key merchant relationships."
    },
    {
      title: "Customer Success Manager",
      department: "Customer Success",
      location: "Remote",
      type: "Full-time",
      description: "Ensure merchant satisfaction and drive retention through exceptional service."
    },
    {
      title: "Payment Processing Specialist",
      department: "Operations",
      location: "Remote",
      type: "Full-time",
      description: "Manage payment processing operations and merchant technical support."
    },
    {
      title: "Marketing Specialist",
      department: "Marketing",
      location: "Remote",
      type: "Full-time",
      description: "Develop and execute marketing campaigns to drive merchant acquisition."
    },
    {
      title: "Software Developer",
      department: "Engineering",
      location: "Remote",
      type: "Full-time",
      description: "Build and maintain our payment processing platform and merchant tools."
    },
    {
      title: "Business Development Representative",
      department: "Sales",
      location: "Remote",
      type: "Full-time",
      description: "Generate qualified leads and support the sales team with prospect research."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="container mx-auto max-w-6xl text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-primary relative z-10 [background:var(--gradient-primary)] [-webkit-background-clip:text] [background-clip:text] [-webkit-text-fill-color:transparent] supports-[not(background-clip:text)]:text-primary">
              Join Our Mission to Revolutionize Payment Processing
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Help us build the future of transparent, fee-free payment processing while growing your career with a company that values innovation and integrity.
            </p>
            <Button size="xl" variant="cta" className="mb-8" onClick={() => document.getElementById('positions')?.scrollIntoView({ behavior: 'smooth' })}>
              View Open Positions
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <div className="flex justify-center">
              <div className="w-32 h-32 bg-gradient-primary rounded-full flex items-center justify-center shadow-glow">
                <Briefcase className="h-16 w-16 text-primary-foreground" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do and define who we are as a company.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-card transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                    <value.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{value.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Work With Us?</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              We offer competitive benefits and a supportive environment where you can thrive.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center hover:shadow-card transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-glow">
                    <benefit.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{benefit.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Open Positions Section */}
      <section id="positions" className="py-16 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Open Positions</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Join our growing team and help shape the future of payment processing.
            </p>
          </div>
          <div className="grid gap-6">
            {openPositions.map((position, index) => (
              <Card key={index} className="hover:shadow-card transition-all duration-300">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <CardTitle className="text-xl mb-2">{position.title}</CardTitle>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary">
                          <Building2 className="mr-1 h-3 w-3" />
                          {position.department}
                        </Badge>
                        <Badge variant="secondary">
                          <MapPin className="mr-1 h-3 w-3" />
                          {position.location}
                        </Badge>
                        <Badge variant="secondary">
                          <Clock className="mr-1 h-3 w-3" />
                          {position.type}
                        </Badge>
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      onClick={() => document.getElementById('application')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                      Apply Now
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">{position.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section id="application" className="py-16 px-4 bg-secondary/30">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Apply Today</h2>
            <p className="text-lg text-muted-foreground">Ready to join our team? Submit your application below.</p>
          </div>
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Job Application</CardTitle>
              <CardDescription>Tell us about yourself and why you'd be a great addition to our team.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input 
                      id="name"
                      value={applicationData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input 
                      id="email"
                      type="email"
                      value={applicationData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="your@email.com"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input 
                      id="phone"
                      type="tel"
                      value={applicationData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="(555) 123-4567"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="position">Position Applied For *</Label>
                    <Select onValueChange={(value) => handleInputChange('position', value)} required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a position" />
                      </SelectTrigger>
                      <SelectContent>
                        {openPositions.map((position, index) => (
                          <SelectItem key={index} value={position.title}>
                            {position.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">Years of Relevant Experience</Label>
                  <Select onValueChange={(value) => handleInputChange('experience', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select experience level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0-1">0-1 years</SelectItem>
                      <SelectItem value="2-5">2-5 years</SelectItem>
                      <SelectItem value="6-10">6-10 years</SelectItem>
                      <SelectItem value="10+">10+ years</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="resume">Resume/CV *</Label>
                  <Input 
                    id="resume"
                    type="file"
                    onChange={handleFileChange}
                    accept=".pdf,.doc,.docx"
                    required
                  />
                  <p className="text-sm text-muted-foreground">Please upload your resume in PDF, DOC, or DOCX format.</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coverLetter">Cover Letter</Label>
                  <Textarea 
                    id="coverLetter"
                    value={applicationData.coverLetter}
                    onChange={(e) => handleInputChange('coverLetter', e.target.value)}
                    placeholder="Tell us why you're interested in this position and what makes you a great fit..."
                    rows={6}
                  />
                </div>

                <Button type="submit" size="lg" className="w-full" variant="cta">
                  Submit Application
                  <Send className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Footer */}
      <section className="py-16 px-4 bg-gradient-primary text-primary-foreground">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Make a Difference in Payment Processing?
          </h2>
          <p className="text-xl mb-8 text-white/90">
            Join our team and help us build a future where businesses don't pay unnecessary fees.
          </p>
          <Button 
            size="xl" 
            variant="secondary" 
            onClick={() => document.getElementById('application')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Apply Now
            <CheckCircle className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Careers;
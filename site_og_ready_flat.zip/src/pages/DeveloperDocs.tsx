import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Code, ArrowLeft, Bell, Calendar, Terminal, Webhook, Shield } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const DeveloperDocs = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <div className="mb-8">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = "/contact"}
                className="mb-6"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Contact
              </Button>
            </div>
            
            <div className="mb-8">
              <div className="w-24 h-24 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Code className="w-12 h-12 text-primary" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Developer Documentation</h1>
              <p className="text-xl text-muted-foreground mb-8">
                Complete API documentation, SDKs, and integration guides for developers.
              </p>
            </div>

            {/* Coming Soon Card */}
            <Card className="max-w-2xl mx-auto shadow-card">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Terminal className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold mb-4">Coming Soon!</h2>
                <p className="text-lg text-muted-foreground mb-8">
                  We're building comprehensive developer documentation with APIs, SDKs, 
                  code samples, and integration guides to make development seamless.
                </p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>RESTful API Documentation</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>SDKs for Popular Languages</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Webhook Integration Guides</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Code Examples & Samples</span>
                  </div>
                </div>

                <Button 
                  variant="cta" 
                  size="lg"
                  onClick={() => window.location.href = "/contact"}
                  className="mb-4"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Get Early Access
                </Button>
                
                <p className="text-sm text-muted-foreground">
                  Need integration help now? Our technical team is ready to assist.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* What's Coming Section */}
        <section className="py-16 px-4 bg-muted/20">
          <div className="container mx-auto max-w-6xl">
            <h3 className="text-2xl font-bold text-center mb-12">What's Coming to Developer Docs</h3>
            
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Code className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle>API Reference</CardTitle>
                  <CardDescription>
                    Complete API documentation with endpoints, parameters, and response examples.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                    <Webhook className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle>SDKs & Libraries</CardTitle>
                  <CardDescription>
                    Pre-built SDKs for Python, Node.js, PHP, and other popular programming languages.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                    <Shield className="w-6 h-6 text-purple-600" />
                  </div>
                  <CardTitle>Security Guides</CardTitle>
                  <CardDescription>
                    Best practices for secure payment processing and PCI compliance guidelines.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* Developer Tools Preview */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <h3 className="text-2xl font-bold mb-8">Developer Tools Preview</h3>
            <Card className="bg-gray-900 text-white">
              <CardContent className="p-8">
                <div className="text-left font-mono text-sm">
                  <div className="text-green-400 mb-2"># Coming Soon: Quick Integration</div>
                  <div className="text-gray-300 mb-4">
                    <span className="text-blue-400">curl</span> -X POST https://api.freecreditcardprocessor.com/v1/payments \<br/>
                    &nbsp;&nbsp;-H <span className="text-yellow-400">"Authorization: Bearer YOUR_API_KEY"</span> \<br/>
                    &nbsp;&nbsp;-H <span className="text-yellow-400">"Content-Type: application/json"</span> \<br/>
                    &nbsp;&nbsp;-d <span className="text-yellow-400">{'{"amount": 1000, "currency": "usd"}'}</span>
                  </div>
                  <div className="text-green-400"># Simple, secure, and zero processing fees</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default DeveloperDocs;
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ClipboardCheck, 
  UserCheck, 
  CreditCard,
  DollarSign,
  Shield,
  CheckCircle,
  XCircle,
  MapPin
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const HowItWorks = () => {
  const steps = [
    {
      icon: <ClipboardCheck className="w-8 h-8" />,
      title: "Apply Online",
      description: "Submit a quick application — no fees, no commitment."
    },
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Get Matched Instantly", 
      description: "We pair you with a top-rated processor who supports zero-cost processing."
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Start Processing Free",
      description: "Accept credit cards and keep 100% of your sales."
    }
  ];

  const comparisonData = [
    { feature: "Setup Fees", traditional: "Yes", free: "No" },
    { feature: "Monthly Service Fees", traditional: "Yes", free: "No" },
    { feature: "Swipe/Transaction Fees", traditional: "Yes", free: "No" },
    { feature: "Who Pays the Fees?", traditional: "You", free: "Your Customer" }
  ];

  const complianceFeatures = [
    "PCI DSS compliant processors",
    "Legal fee disclosures & signage provided",
    "State-by-state compliance ensured",
    "Proper terminal programming included"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-subtle">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            How Free Credit Card Processing Actually Works
          </h1>
          <h2 className="text-xl md:text-2xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            We eliminate your merchant fees by using a compliant, legal model that shifts processing costs to the customer — so you keep 100% of every sale.
          </h2>
        </div>
      </section>

      {/* 3-Step Visual Explainer */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <Card className="p-8 text-center hover:shadow-card transition-smooth bg-card border-border">
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                      {index + 1}
                    </div>
                  </div>
                  
                  <div className="flex justify-center mb-6 mt-4">
                    <div className="p-4 bg-gradient-primary rounded-full text-primary-foreground">
                      {step.icon}
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </Card>

                {/* Connector arrow for desktop */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 text-primary">
                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="text-center">
            <Button variant="cta" size="lg" onClick={() => window.location.href = "/onboard"}>
              See If You Qualify
            </Button>
          </div>
        </div>
      </section>

      {/* What Makes It Free */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-8">
              Who Pays the Fees Instead?
            </h2>
            
            <Card className="p-8 mb-8 bg-card border-border">
              <p className="text-lg text-foreground mb-6 leading-relaxed">
                <strong>The customer does</strong> — through a small checkout adjustment. It's a compliant program known as:
              </p>
              
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-center gap-3">
                  <DollarSign className="w-6 h-6 text-primary" />
                  <div>
                    <h4 className="font-semibold text-foreground">Surcharging</h4>
                    <p className="text-muted-foreground text-sm">For credit cards</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <DollarSign className="w-6 h-6 text-primary" />
                  <div>
                    <h4 className="font-semibold text-foreground">Cash Discounting</h4>
                    <p className="text-muted-foreground text-sm">For all transactions</p>
                  </div>
                </div>
              </div>
              
              <p className="text-muted-foreground">
                This model is approved in most U.S. states and widely adopted in gas stations, utilities, and local businesses.
              </p>
            </Card>

            {/* Visual Example */}
            <Card className="p-8 bg-gradient-subtle border-border">
              <h3 className="text-xl font-semibold text-center text-foreground mb-6">
                Here's How It Works:
              </h3>
              <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-center">
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-3">
                    <CreditCard className="w-8 h-8 text-primary" />
                  </div>
                  <p className="text-sm text-muted-foreground">Customer swipes card</p>
                  <p className="font-semibold text-foreground">Pays $102.50</p>
                  <p className="text-xs text-muted-foreground">for $100 item</p>
                </div>
                
                <div className="hidden md:block">
                  <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
                
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-success/20 rounded-full flex items-center justify-center mb-3">
                    <DollarSign className="w-8 h-8 text-success" />
                  </div>
                  <p className="text-sm text-muted-foreground">Business keeps</p>
                  <p className="font-semibold text-success">Full $100</p>
                  <p className="text-xs text-muted-foreground">No fees deducted</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Traditional vs Free Comparison */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-12">
            Traditional vs. Free Processing
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <Card className="overflow-hidden bg-card border-border">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-6 font-semibold text-foreground">Feature</th>
                      <th className="text-center p-6 font-semibold text-foreground">Traditional Processor</th>
                      <th className="text-center p-6 font-semibold text-primary bg-primary/5">FreeCreditCardProcessor.com</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonData.map((row, index) => (
                      <tr key={index} className="border-b border-border last:border-b-0">
                        <td className="p-6 font-medium text-foreground">{row.feature}</td>
                        <td className="text-center p-6">
                          {row.traditional === "Yes" ? (
                            <div className="flex items-center justify-center gap-2">
                              <XCircle className="w-5 h-5 text-destructive" />
                              <span className="text-destructive font-medium">{row.traditional}</span>
                            </div>
                          ) : (
                            <span className="text-foreground">{row.traditional}</span>
                          )}
                        </td>
                        <td className="text-center p-6 bg-primary/5">
                          {row.free === "No" ? (
                            <div className="flex items-center justify-center gap-2">
                              <CheckCircle className="w-5 h-5 text-success" />
                              <span className="text-success font-medium">{row.free}</span>
                            </div>
                          ) : (
                            <span className="text-primary font-medium">{row.free}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Legal & Compliance */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              Is It Legal & Compliant?
            </h2>
            
            <div className="flex items-center justify-center gap-3 mb-8">
              <Shield className="w-8 h-8 text-success" />
              <p className="text-2xl font-semibold text-success">Yes — And We Make Sure You're Fully Covered</p>
            </div>
            
            <Card className="p-8 bg-card border-border">
              <p className="text-lg text-foreground mb-6">
                All processors we work with:
              </p>
              
              <div className="grid md:grid-cols-2 gap-4">
                {complianceFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3 text-left">
                    <CheckCircle className="w-5 h-5 text-success flex-shrink-0" />
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-8 p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-2 justify-center">
                  <MapPin className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">
                    Surcharge programs are legal in most U.S. states. We ensure compliance in your area.
                  </span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-16 bg-gradient-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Start Saving on Every Sale — Instantly
          </h2>
          
          <p className="text-xl mb-8 opacity-90">
            Takes 60 seconds. No contracts. No obligations.
          </p>
          
          <Button 
            variant="hero" 
            size="xl"
            onClick={() => window.location.href = "/onboard"}
            className="bg-background text-primary hover:bg-background/90"
          >
            Apply for Free Processing
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HowItWorks;
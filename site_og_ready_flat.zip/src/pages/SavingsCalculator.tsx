import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { DollarSign, Calculator, Mail, CheckCircle, Shield } from "lucide-react";

const SavingsCalculator = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    monthlySales: ""
  });
  
  const [showResults, setShowResults] = useState(false);
  const [calculatedSavings, setCalculatedSavings] = useState({
    monthlyFees: 0,
    annualFees: 0,
    monthlySavings: 0,
    annualSavings: 0
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateSavings = () => {
    const sales = parseFloat(formData.monthlySales.replace(/[^0-9.]/g, '')) || 0;
    
    // Traditional processor costs (2.9% + $0.30 per transaction + monthly fees)
    const processingRate = 0.029;
    const perTransactionFee = 0.30;
    const avgTransactionSize = 50; // Assume $50 average
    const monthlyTransactions = sales / avgTransactionSize;
    const monthlyFixedFees = 25; // Terminal rental, PCI compliance, etc.
    
    const monthlyProcessingFees = sales * processingRate;
    const monthlyTransactionFees = monthlyTransactions * perTransactionFee;
    const totalMonthlyFees = monthlyProcessingFees + monthlyTransactionFees + monthlyFixedFees;
    
    // Our solution saves 100% of processing fees (we make money from cash discount)
    const monthlySavings = totalMonthlyFees;
    
    setCalculatedSavings({
      monthlyFees: totalMonthlyFees,
      annualFees: totalMonthlyFees * 12,
      monthlySavings: monthlySavings,
      annualSavings: monthlySavings * 12
    });
    
    setShowResults(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    calculateSavings();
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Calculate Your Savings
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              See exactly how much you could save by switching to zero-cost credit card processing
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Form Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-primary" />
                  Get Your Savings Estimate
                </CardTitle>
                <CardDescription>
                  Fill out the form below to see your potential savings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      placeholder="Enter your full name"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="Enter your email address"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      placeholder="(555) 123-4567"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="monthlySales">Monthly Credit Card Sales *</Label>
                    <Input
                      id="monthlySales"
                      value={formData.monthlySales}
                      onChange={(e) => handleInputChange("monthlySales", e.target.value)}
                      placeholder="$10,000"
                      required
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      Enter your approximate monthly credit card processing volume
                    </p>
                  </div>
                  
                  <Button type="submit" size="lg" className="w-full">
                    <DollarSign className="w-4 h-4 mr-2" />
                    Calculate My Savings
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Results Section */}
            {showResults ? (
              <Card className="border-primary/20 bg-primary/5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-primary">
                    <CheckCircle className="w-5 h-5" />
                    Your Savings Estimate
                  </CardTitle>
                  <CardDescription>
                    Based on {formatCurrency(parseFloat(formData.monthlySales.replace(/[^0-9.]/g, '')) || 0)} monthly sales
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-background rounded-lg">
                      <div className="text-2xl font-bold text-destructive">
                        {formatCurrency(calculatedSavings.monthlyFees)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Current Monthly Fees
                      </div>
                    </div>
                    
                    <div className="text-center p-4 bg-background rounded-lg">
                      <div className="text-2xl font-bold text-primary">
                        $0
                      </div>
                      <div className="text-sm text-muted-foreground">
                        With Our Solution
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center p-6 bg-primary text-primary-foreground rounded-lg">
                    <div className="text-3xl font-bold mb-2">
                      {formatCurrency(calculatedSavings.annualSavings)}
                    </div>
                    <div className="text-primary-foreground/80">
                      Total Annual Savings
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>Zero processing fees with cash discount program</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>Free equipment and setup</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                      <span>24/7 customer support</span>
                    </div>
                  </div>
                  
                  <Button size="lg" className="w-full" onClick={() => window.location.href = "/onboard"}>
                    <Mail className="w-4 h-4 mr-2" />
                    Get Started Now
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-dashed">
                <CardContent className="flex items-center justify-center h-full p-8">
                  <div className="text-center text-muted-foreground">
                    <Calculator className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>Fill out the form to see your savings estimate</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Trust Indicators */}
          <div className="mt-16 text-center">
            <div className="grid md:grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">Secure & Compliant</h3>
                <p className="text-sm text-muted-foreground">PCI DSS Level 1 compliant processing</p>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                  <DollarSign className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">Zero Hidden Fees</h3>
                <p className="text-sm text-muted-foreground">Transparent pricing with no surprises</p>
              </div>
              
              <div className="flex flex-col items-center">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-3">
                  <CheckCircle className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold mb-1">Proven Results</h3>
                <p className="text-sm text-muted-foreground">Thousands of businesses saving money daily</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default SavingsCalculator;
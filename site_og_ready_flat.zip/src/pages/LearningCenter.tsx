import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, ArrowLeft, Bell, Calendar, Users } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const LearningCenter = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <div className="mb-8">
              <Button 
                variant="ghost" 
                onClick={() => window.location.href = "/contact"}
                className="mb-6"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Contact
              </Button>
            </div>
            
            <div className="mb-8">
              <div className="w-24 h-24 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <BookOpen className="w-12 h-12 text-primary" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Learning Center</h1>
              <p className="text-xl text-muted-foreground mb-8">
                Your comprehensive resource for payment processing education, tutorials, and best practices.
              </p>
            </div>

            {/* Coming Soon Card */}
            <Card className="max-w-2xl mx-auto shadow-card">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 bg-gradient-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Calendar className="w-8 h-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold mb-4">Coming Soon!</h2>
                <p className="text-lg text-muted-foreground mb-8">
                  We're building an amazing learning center with step-by-step guides, video tutorials, 
                  and expert insights to help you master payment processing.
                </p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Getting Started Guides</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Video Tutorials</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Industry Best Practices</span>
                  </div>
                  <div className="flex items-center gap-3 text-left">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span>Troubleshooting Guides</span>
                  </div>
                </div>

                <Button 
                  variant="cta" 
                  size="lg"
                  onClick={() => window.location.href = "/contact"}
                  className="mb-4"
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Get Notified When Available
                </Button>
                
                <p className="text-sm text-muted-foreground">
                  In the meantime, our support team is ready to help with any questions.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* What's Coming Section */}
        <section className="py-16 px-4 bg-muted/20">
          <div className="container mx-auto max-w-6xl">
            <h3 className="text-2xl font-bold text-center mb-12">What's Coming to the Learning Center</h3>
            
            <div className="grid md:grid-cols-3 gap-8">
              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <BookOpen className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle>Quick Start Guides</CardTitle>
                  <CardDescription>
                    Step-by-step tutorials to get your payment processing up and running in minutes.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                    <Users className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle>Video Tutorials</CardTitle>
                  <CardDescription>
                    Interactive video content covering everything from basic setup to advanced features.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                    <Calendar className="w-6 h-6 text-purple-600" />
                  </div>
                  <CardTitle>Webinar Series</CardTitle>
                  <CardDescription>
                    Regular live sessions with payment experts covering industry trends and tips.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default LearningCenter;
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card } from "@/components/ui/card";

const Terms = () => {
  const sections = [
    { id: "introduction", title: "Introduction" },
    { id: "website-use", title: "Use of the Website" },
    { id: "services", title: "Services Provided" },
    { id: "no-guarantee", title: "No Guarantee or Endorsement" },
    { id: "intellectual-property", title: "Intellectual Property" },
    { id: "liability", title: "Limitation of Liability" },
    { id: "modifications", title: "Modifications to the Terms" },
    { id: "governing-law", title: "Governing Law" },
    { id: "contact", title: "Contact Information" }
  ];

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-8 bg-gradient-subtle">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Terms of Service
            </h1>
            <p className="text-lg text-muted-foreground">
              Last Updated: July 2025
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Table of Contents */}
          <Card className="p-6 mb-8 bg-card border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">Table of Contents</h2>
            <nav className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {sections.map((section, index) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className="text-left text-primary hover:text-primary/80 transition-colors text-sm py-1"
                >
                  {index + 1}. {section.title}
                </button>
              ))}
            </nav>
          </Card>

          {/* Content Sections */}
          <div className="prose prose-gray max-w-none">
            {/* Introduction */}
            <section id="introduction" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                1. Introduction
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <h3 className="text-lg font-medium text-foreground mb-3">
                  Welcome to FreeCreditCardProcessor.com
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  These Terms of Service ("Terms") govern your access to and use of FreeCreditCardProcessor.com ("we," "our," or "the Company"). By accessing our site or services, you agree to these Terms. If you do not agree, you must not use the site.
                </p>
              </div>
            </section>

            {/* Use of the Website */}
            <section id="website-use" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                2. Use of the Website
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    You must be at least 18 years old to use this site.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    You agree to use the website lawfully and not misuse or tamper with the services.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    We reserve the right to suspend or terminate access for violations.
                  </li>
                </ul>
              </div>
            </section>

            {/* Services Provided */}
            <section id="services" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                3. Services Provided
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground leading-relaxed">
                  We offer information and referral services for credit card processing and other merchant-related financial products. Submitting a form does not guarantee approval or service.
                </p>
              </div>
            </section>

            {/* No Guarantee or Endorsement */}
            <section id="no-guarantee" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                4. No Guarantee or Endorsement
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    We connect you to third-party processors and financial providers.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    We do not guarantee any specific outcome, savings, or merchant account approval.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    All financial decisions are your responsibility and should be made with proper due diligence.
                  </li>
                </ul>
              </div>
            </section>

            {/* Intellectual Property */}
            <section id="intellectual-property" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                5. Intellectual Property
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <ul className="space-y-3 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    All content, branding, text, graphics, and site design are the property of FreeCreditCardProcessor.com or its licensors.
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    You may not copy, reproduce, or use content without written permission.
                  </li>
                </ul>
              </div>
            </section>

            {/* Limitation of Liability */}
            <section id="liability" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                6. Limitation of Liability
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">We are not liable for:</p>
                <ul className="space-y-3 text-muted-foreground mb-4">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Third-party services or damages resulting from your business decisions
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Temporary outages, service interruptions, or data loss
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Any indirect, incidental, or consequential damages
                  </li>
                </ul>
                <p className="text-foreground font-medium">
                  Use of this website is at your own risk.
                </p>
              </div>
            </section>

            {/* Modifications to the Terms */}
            <section id="modifications" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                7. Modifications to the Terms
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground leading-relaxed">
                  We reserve the right to update or modify these Terms at any time. Changes will be posted here with an updated "Last Updated" date. Continued use of the site after changes constitutes acceptance.
                </p>
              </div>
            </section>

            {/* Governing Law */}
            <section id="governing-law" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                8. Governing Law
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground leading-relaxed">
                  These Terms shall be governed by the laws of the State of Michigan, without regard to its conflict of laws principles.
                </p>
              </div>
            </section>

            {/* Contact Information */}
            <section id="contact" className="mb-12">
              <h2 className="text-2xl font-semibold text-foreground mb-4">
                9. Contact Information
              </h2>
              <div className="bg-card p-6 rounded-lg border border-border">
                <p className="text-muted-foreground mb-4">For questions about these Terms:</p>
                <div className="space-y-2 text-muted-foreground">
                  <p className="flex items-center gap-2">
                    <span className="text-primary">📧</span>
                    support@freecreditcardprocessor.com
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="text-primary">📞</span>
                    (888) XXX-XXXX
                  </p>
                </div>
              </div>
            </section>
          </div>

          {/* Link to Privacy Policy */}
          <Card className="p-6 mt-8 bg-muted/30 border-border">
            <p className="text-center text-muted-foreground">
              Also see our{" "}
              <a 
                href="/privacy" 
                className="text-primary hover:text-primary/80 underline transition-colors"
              >
                Privacy Policy
              </a>
            </p>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Terms;
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, MessageSquare, Calendar, HeadphonesIcon, BookOpen, Code, Briefcase, Users, MessageCircle, HelpCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    businessName: "",
    phoneNumber: "",
    email: "",
    isCurrentMerchant: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Request Submitted!",
        description: "Thanks! A support rep will call you within 1 business day.",
      });
      setFormData({
        name: "",
        businessName: "",
        phoneNumber: "",
        email: "",
        isCurrentMerchant: "",
        message: ""
      });
      setIsSubmitting(false);
    }, 1000);
  };

  const scrollToForm = () => {
    document.getElementById('callback-form')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">We're Here to Help</h1>
            <p className="text-xl text-muted-foreground mb-12">
              Whether you're an existing merchant or just exploring, our support team is ready to assist you — by phone, ticket, or live demo.
            </p>
          </div>
        </section>

        {/* Direct Contact Options */}
        <section className="py-12 px-4">
          <div className="container mx-auto max-w-6xl">
            <Card className="shadow-card">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-2 gap-12 items-center">
                  <div className="space-y-8">
                    <div className="flex items-start gap-4">
                      <div className="bg-primary/10 p-3 rounded-lg">
                        <Phone className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Phone Support</h3>
                        <p className="text-2xl font-bold text-primary mb-2">734-590-3315</p>
                        <p className="text-sm text-muted-foreground">
                          Monday–Friday, 8am–6pm EST<br />
                          Saturday, 10am–3pm EST
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <MessageSquare className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Submit a Ticket</h3>
                        <p className="text-muted-foreground mb-3">
                          Already a merchant? Send us a request if you need any support.
                        </p>
                        <Button variant="outline" size="sm">
                          Submit a Support Ticket
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-6">
                    <div className="flex items-start gap-4 w-full">
                      <div className="bg-purple-100 p-3 rounded-lg">
                        <MessageCircle className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2">Chat with Sales</h3>
                        <p className="text-muted-foreground mb-3">
                          Book a live demo or get your questions answered by our payment specialists.
                        </p>
                        <Button variant="cta" size="sm" onClick={() => window.location.href = "/onboard"}>
                          Book a Demo
                        </Button>
                      </div>
                    </div>
                    
                    {/* Illustration placeholder */}
                    <div className="w-48 h-32 bg-gradient-to-br from-primary/10 to-purple-100 rounded-xl flex items-center justify-center">
                      <div className="flex gap-4">
                        <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-primary" />
                        </div>
                        <div className="w-12 h-12 bg-purple-200 rounded-full flex items-center justify-center">
                          <MessageCircle className="w-6 h-6 text-purple-600" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Help Blocks Grid */}
        <section className="py-12 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <Card className="bg-purple-50 border-purple-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={scrollToForm}>
                <CardHeader className="text-center">
                   <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                     <Phone className="w-8 h-8 text-purple-600" />
                   </div>
                   <CardTitle className="text-lg">Have us call you</CardTitle>
                   <CardDescription>
                     We'll call you back within one business day.
                   </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-pink-50 border-pink-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = "/learning-center"}>
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-8 h-8 text-pink-600" />
                  </div>
                  <CardTitle className="text-lg">Learning Center</CardTitle>
                  <CardDescription>
                    Helpful articles and tutorials to get you started.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card className="bg-orange-50 border-orange-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => window.location.href = "/developer-docs"}>
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Code className="w-8 h-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-lg">Developer Docs</CardTitle>
                  <CardDescription>
                    Detailed documentation for our developer tools.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>

            {/* Other Inquiries */}
            <Card className="bg-muted/30">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold mb-6 text-center">Need help with other inquiries?</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="flex items-center gap-3">
                    <Briefcase className="w-5 h-5 text-primary" />
                    <div>
                      <h4 className="font-medium">Careers</h4>
                      <p className="text-sm text-muted-foreground">Join our amazing team!</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-primary" />
                    <div>
                      <h4 className="font-medium">Sales</h4>
                      <p className="text-sm text-muted-foreground">Let us help you make an informed decision</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <HeadphonesIcon className="w-5 h-5 text-primary" />
                    <div>
                      <h4 className="font-medium">Partner with Us</h4>
                      <p className="text-sm text-muted-foreground">Become a partner and help us help small businesses</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 text-primary" />
                    <div>
                      <h4 className="font-medium">Need a hand?</h4>
                      <p className="text-sm text-muted-foreground">Submit a ticket and our team will guide you every step of the way</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Callback Form */}
        <section id="callback-form" className="py-16 px-4 bg-muted/20">
          <div className="container mx-auto max-w-2xl">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Request a Callback</h2>
            </div>

            <Card>
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Name</label>
                      <Input
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Your name"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Phone Number</label>
                      <Input
                        value={formData.phoneNumber}
                        onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
                        placeholder="Your phone number"
                        type="tel"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Business Name (optional)</label>
                      <Input
                        value={formData.businessName}
                        onChange={(e) => handleInputChange('businessName', e.target.value)}
                        placeholder="Your business name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Email</label>
                      <Input
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="Your email address"
                        type="email"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Are you a current merchant?</label>
                    <Select value={formData.isCurrentMerchant} onValueChange={(value) => handleInputChange('isCurrentMerchant', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Message (optional)</label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      placeholder="Tell us how we can help..."
                      rows={4}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    variant="cta" 
                    size="lg" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Submitting..." : "Submit"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Contact;

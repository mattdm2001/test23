import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Users, Clock, TrendingUp, Heart, CheckCircle } from "lucide-react";

const About = () => {
  const navigate = useNavigate();
  const values = [
    {
      icon: Shield,
      title: "Transparency",
      description: "No hidden fees. No contracts. No surprises."
    },
    {
      icon: CheckCircle,
      title: "Simplicity", 
      description: "Straightforward setup. No technical headaches."
    },
    {
      icon: Users,
      title: "Support",
      description: "Real people. Real service. Whenever you need us."
    },
    {
      icon: TrendingUp,
      title: "Empowerment",
      description: "More money in your pocket means more power to grow your business."
    }
  ];

  const teamMembers = [
    {
      name: "Evan Pie",
      role: "CEO",
      description: "12 years working with institutional processors.",
      initials: "EP"
    },
    {
      name: "Michael Chen",
      role: "CTO",
      description: "Former fintech engineer, built payment systems for 1M+ merchants.",
      initials: "MC"
    },
    {
      name: "Matthew Morrow",
      role: "Head of Partnerships",
      description: "Veteran ISO with deep merchant services expertise.",
      initials: "MM"
    }
  ];

  const stats = [
    { number: "5,000+", label: "Merchants Served" },
    { number: "$15M+", label: "Fees Saved" },
    { number: "50", label: "States Covered" },
    { number: "24/7", label: "Support Available" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-hero">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center text-white">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              We Believe You Shouldn't Have to Pay to Get Paid
            </h1>
            <p className="text-xl md:text-2xl text-white/90 leading-relaxed">
              Our mission is simple: eliminate credit card processing fees for small and mid-sized businesses — forever.
            </p>
          </div>
        </div>
      </section>

      <main className="py-16 space-y-24">
        {/* Who We Are Section */}
        <section className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-foreground mb-6">
                We're Industry Veterans Who Knew There Was a Better Way
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                With over 15 years in payments and small business finance, we've seen too many entrepreneurs lose thousands to hidden processing fees. That's why we built a smarter solution — one that puts your revenue back where it belongs: in your business.
              </p>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-12">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Core Values Section */}
        <section className="container mx-auto px-4 bg-muted/30 py-16 rounded-2xl">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-foreground mb-12">
              Our Core Values
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <Card key={index} className="border-0 shadow-card hover:shadow-elegant transition-shadow">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                      <value.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Our Impact Section */}
        <section className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-bold text-foreground mb-6">
              A Growing Community of Zero-Fee Businesses
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              "We've helped business owners collectively save over $15 million in fees — and counting."
            </p>
            
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge variant="secondary" className="text-sm py-2 px-4">Restaurants</Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">Retail Stores</Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">Service Businesses</Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">Online Shops</Badge>
              <Badge variant="secondary" className="text-sm py-2 px-4">Franchises</Badge>
            </div>
            
            <Button size="lg" variant="cta" className="mt-4" onClick={() => navigate('/onboard')}>
              <Heart className="mr-2 h-5 w-5" />
              Join the Movement
            </Button>
          </div>
        </section>

        {/* Team Section */}
        <section className="container mx-auto px-4 bg-muted/30 py-16 rounded-2xl">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-center text-foreground mb-12">
              Meet the Team
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              {teamMembers.map((member, index) => (
                <Card key={index} className="border-0 shadow-card hover:shadow-elegant transition-shadow">
                  <CardContent className="p-6 text-center">
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center text-white font-bold text-xl">
                      {member.initials}
                    </div>
                    <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
                    <p className="text-primary font-medium mb-3">{member.role}</p>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {member.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA Section */}
        <section className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center bg-gradient-primary rounded-2xl p-12 text-white">
            <h2 className="text-4xl font-bold mb-6">
              Ready to Eliminate Your Credit Card Processing Fees?
            </h2>
            <p className="text-xl mb-8 text-white/90">
              Join thousands of businesses already saving money with our zero-fee processing solution.
            </p>
            <Button size="xl" variant="secondary" className="bg-white text-primary hover:bg-white/90" onClick={() => navigate('/onboard')}>
              <Clock className="mr-2 h-5 w-5" />
              See If You Qualify
            </Button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default About;
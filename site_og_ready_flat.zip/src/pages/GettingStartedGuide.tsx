import { ArrowLeft, FileText, Shield, CreditCard, CheckCircle, Phone, MessageCircle, Mail } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const GettingStartedGuide = () => {
  const steps = [
    {
      number: 1,
      title: "Understand How It Works",
      icon: FileText,
      content: [
        "You pay $0 in processing fees.",
        "The processing cost is passed to the customer via a small checkout adjustment.",
        "This is a compliant and legal program in most U.S. states.",
        "You keep 100% of your sales revenue."
      ],
      tip: 'Read our "How It Works" page for a simple breakdown of the surcharging/cash discount process.'
    },
    {
      number: 2,
      title: "Gather Your Basic Information",
      icon: FileText,
      content: [
        "Business name and DBA (if applicable)",
        "Business address and contact info",
        "Estimated monthly card volume and average ticket size",
        "Type of POS system you currently use (if any)",
        "Bank account details for deposits"
      ],
      tip: "If you don't have a POS yet, don't worry — we can provide compliant terminals."
    },
    {
      number: 3,
      title: "Fill Out the Online Application",
      icon: CreditCard,
      content: [
        "Enter your business details.",
        "Provide ownership information (name, date of birth, last 4 digits of SSN for verification).",
        "Add banking info for payouts.",
        "Upload required documents:"
      ],
      subItems: [
        "Driver's license (front + back)",
        "Voided business check or bank letter",
        "Recent processing statement (if switching from another provider)"
      ],
      tip: "All data is encrypted and stored securely."
    },
    {
      number: 4,
      title: "Application Review",
      icon: Shield,
      content: [
        "Our team reviews your information for approval.",
        "You'll be contacted within 1 business day with next steps.",
        "If approved, you'll receive:"
      ],
      subItems: [
        "Confirmation email",
        "Instructions for setup",
        "Shipping details for any needed equipment"
      ]
    },
    {
      number: 5,
      title: "Install & Go Live",
      icon: CheckCircle,
      content: [
        "If you're using existing POS equipment: We'll remotely configure it for zero-cost processing.",
        "If you're receiving new equipment: We'll ship terminals with pre-loaded compliance software.",
        "You'll receive customer signage to display at checkout."
      ],
      tip: "The setup process usually takes less than 30 minutes."
    },
    {
      number: 6,
      title: "Start Accepting Payments (for Free!)",
      icon: CreditCard,
      content: [
        "Begin processing credit card transactions.",
        "Keep 100% of your sales.",
        "Your customers cover the processing cost.",
        "Track deposits and transactions in your merchant portal."
      ]
    },
    {
      number: 7,
      title: "Ongoing Support",
      icon: Phone,
      content: [
        "Our U.S.-based support team is available by:",
        "You'll also have access to our Help Center with articles, guides, and FAQs."
      ],
      supportOptions: [
        { icon: Phone, label: "Phone" },
        { icon: MessageCircle, label: "Live Chat" },
        { icon: Mail, label: "Email Support" }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => window.history.back()}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Help Center
            </Button>
          </div>
          
          <div className="max-w-4xl">
            <Badge variant="secondary" className="mb-4">Getting Started</Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              How to Apply for Free Credit Card Processing
            </h1>
            <p className="text-xl text-muted-foreground">
              Complete Step-by-Step Guide to Getting Started
            </p>
          </div>
        </div>
      </section>

      {/* Steps Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-8">
            {steps.map((step, index) => (
              <Card key={index} className="relative overflow-hidden">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold text-lg">
                        {step.number}
                      </div>
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-2xl flex items-center gap-3 mb-2">
                        <step.icon className="w-6 h-6 text-primary" />
                        Step {step.number} – {step.title}
                      </CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pl-20">
                  <ul className="space-y-3 mb-4">
                    {step.content.map((item, itemIndex) => (
                      <li key={itemIndex} className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-foreground">{item}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {step.subItems && (
                    <ul className="space-y-2 ml-6 mb-4">
                      {step.subItems.map((subItem, subIndex) => (
                        <li key={subIndex} className="flex items-start gap-3">
                          <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full mt-2.5 flex-shrink-0"></div>
                          <span className="text-muted-foreground">{subItem}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  
                  {step.supportOptions && (
                    <div className="flex flex-wrap gap-4 mb-4">
                      {step.supportOptions.map((option, optionIndex) => (
                        <div key={optionIndex} className="flex items-center gap-2 text-primary">
                          <option.icon className="w-4 h-4" />
                          <span className="font-medium">{option.label}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {step.tip && (
                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 mt-4">
                      <div className="flex items-start gap-2">
                        <span className="text-primary font-semibold">💡 Tip:</span>
                        <span className="text-primary">{step.tip}</span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-background">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Click below to begin your Free Credit Card Processing application:
            </p>
            <Button size="lg" onClick={() => window.location.href = "/onboard"} className="text-lg px-8 py-4">
              📌 Apply Now – It's 100% Free
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default GettingStartedGuide;
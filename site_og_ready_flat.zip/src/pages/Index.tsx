import Header from "@/components/Header";
import Hero from "@/components/Hero";
import ValueProposition from "@/components/ValueProposition";
import HowItWorksPreview from "@/components/HowItWorksPreview";
import PricingComparison from "@/components/PricingComparison";
import Testimonials from "@/components/Testimonials";
import FAQ from "@/components/FAQ";
import LeadCapture from "@/components/LeadCapture";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <ValueProposition />
      <HowItWorksPreview />
      <PricingComparison />
      <Testimonials />
      <FAQ />
      <LeadCapture />
      <Footer />
    </div>
  );
};

export default Index;

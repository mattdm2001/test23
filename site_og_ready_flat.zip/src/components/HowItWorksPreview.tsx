import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { ClipboardCheck, UserCheck, CreditCard } from "lucide-react";

const HowItWorksPreview = () => {
  const navigate = useNavigate();
  const steps = [
    {
      icon: <ClipboardCheck className="w-8 h-8" />,
      title: "Fill out a short form",
      description: "Tell us about your business and payment needs in just 2 minutes."
    },
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Get matched with the best processor",
      description: "We connect you with a zero-fee payment processor that fits your business."
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Start accepting payments",
      description: "Begin processing cards immediately with no setup or monthly fees."
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Getting free credit card processing is simple and straightforward.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-8 md:mb-12">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="p-8 text-center hover:shadow-card transition-smooth bg-card border-border">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </div>
                </div>
                
                <div className="flex justify-center mb-6 mt-4">
                  <div className="p-4 bg-gradient-primary rounded-full text-primary-foreground">
                    {step.icon}
                  </div>
                </div>
                
                <h3 className="text-xl font-semibold text-foreground mb-4">
                  {step.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </Card>

              {/* Connector arrow for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2 text-primary">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center">
          <Button 
            variant="cta" 
            size="lg"
            onClick={() => navigate("/pricing")}
          >
            See Full Breakdown
          </Button>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksPreview;
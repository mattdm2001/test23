import { Card } from "@/components/ui/card";
import { CheckCircle, DollarSign, FileText, Zap } from "lucide-react";

const ValueProposition = () => {
  const benefits = [
    {
      icon: <DollarSign className="w-8 h-8" />,
      title: "No Setup Fees",
      description: "Get started immediately without any upfront costs or hidden charges."
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "No Monthly Fees", 
      description: "Keep more of your revenue - no recurring monthly subscription fees."
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "No Contracts",
      description: "Month-to-month flexibility with no long-term commitments required."
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Next-Day Payouts",
      description: "Get your money fast with automatic next business day deposits."
    }
  ];

  return (
    <section className="py-16 bg-gradient-section">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why pay to get <span className="text-primary">paid</span>?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Traditional payment processors charge you to accept money. We believe that's backwards.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          {benefits.map((benefit, index) => (
            <Card key={index} className="p-6 text-center hover:shadow-elegant transition-smooth bg-card border-border">
              <div className="flex justify-center mb-4">
                <div className="p-3 bg-gradient-primary rounded-full text-primary-foreground">
                  {benefit.icon}
                </div>
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">
                {benefit.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {benefit.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ValueProposition;
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
const heroPayment = "/lovable-uploads/3d0c3f20-5bf5-47da-8c13-295668449356.png";

const Hero = () => {
  const navigate = useNavigate();
  return (
    <section className="pt-24 pb-16 bg-gradient-hero relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-primary-foreground mb-4 sm:mb-6 leading-tight">
              Free Credit Card Processing
              <span className="block text-primary-glow">for Small Businesses</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-primary-foreground/90 mb-6 sm:mb-8 leading-relaxed">
              Start accepting card payments with <span className="font-semibold">no setup fees</span>, 
              <span className="font-semibold"> no monthly charges</span>, and 
              <span className="font-semibold"> no contracts</span>.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                variant="cta" 
                size="xl"
                onClick={() => navigate("/onboard")}
              >
                Get Started Free
              </Button>
              <Button 
                variant="outline" 
                size="xl" 
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                onClick={() => window.location.href = "/how-it-works"}
              >
                See How It Works
              </Button>
            </div>

            {/* Trust Badge */}
            <div className="mt-6 sm:mt-8 flex items-center gap-2 justify-center lg:justify-start">
              <div className="text-xs sm:text-sm text-primary-foreground/80 text-center lg:text-left">
                ✓ No credit check required<br className="sm:hidden" />
                <span className="hidden sm:inline"> • </span>✓ Setup in 24 hours<br className="sm:hidden" />
                <span className="hidden sm:inline"> • </span>✓ No hidden fees
              </div>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="relative z-10">
              <div className="relative w-full max-w-lg mx-auto rounded-2xl overflow-hidden shadow-glow">
                <img 
                  src={heroPayment} 
                  alt="Credit card payment processing" 
                  className="w-full h-auto"
                />
                {/* Gradient overlay to blend with hero background */}
                <div className="absolute inset-0 bg-gradient-hero opacity-20 mix-blend-overlay"></div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute top-4 right-4 w-20 h-20 bg-primary-glow/30 rounded-full blur-xl"></div>
            <div className="absolute bottom-8 left-8 w-16 h-16 bg-white/20 rounded-full blur-lg"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
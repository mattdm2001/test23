import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet";
import { Menu, X } from "lucide-react";
import logoIcon from "@/assets/logo-icon.jpg";

const Header = () => {
  const navItems = [
    { name: "How It Works", href: "/how-it-works" },
    { name: "Pricing", href: "/pricing" },
    { name: "Partner", href: "/partner" },
    { name: "Careers", href: "/careers" },
    { name: "About", href: "/about" },
    { name: "FAQs", href: "/faq" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border shadow-card">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <button 
          onClick={() => window.location.href = "/"}
          className="flex items-center gap-4 hover:opacity-80 transition-smooth group"
        >
          <div className="relative">
            <img 
              src={logoIcon} 
              alt="Free Credit Card Processing" 
              className="w-12 h-12 rounded-lg shadow-elegant group-hover:shadow-glow transition-smooth object-center object-cover"
            />
          </div>
          <div className="flex items-center">
            <span className="font-bold text-lg md:text-xl bg-gradient-primary bg-clip-text text-transparent">
              FREECreditCardProcessor.com
            </span>
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="text-muted-foreground hover:text-primary transition-smooth font-medium"
            >
              {item.name}
            </a>
          ))}
        </nav>

        {/* Desktop CTA Button */}
        <div className="hidden md:block">
          <Button variant="hero" size="lg" onClick={() => window.location.href = "/onboard"}>
            Get Started Free
          </Button>
        </div>

        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="sm" className="p-2">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <div className="flex flex-col space-y-4 mt-6">
              {navItems.map((item) => (
                <SheetClose asChild key={item.name}>
                  <a
                    href={item.href}
                    className="text-lg font-medium text-foreground hover:text-primary transition-smooth py-2 border-b border-border"
                  >
                    {item.name}
                  </a>
                </SheetClose>
              ))}
              <div className="pt-4">
                <Button 
                  variant="hero" 
                  size="lg" 
                  className="w-full"
                  onClick={() => window.location.href = "/onboard"}
                >
                  Get Started Free
                </Button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
};

export default Header;
import logoIcon from "@/assets/logo-icon.jpg";

const Footer = () => {
  const footerLinks = {
    company: [
      { name: "About Us", href: "/about" },
      { name: "How It Works", href: "/how-it-works" },
      { name: "Pricing", href: "/pricing" },
      { name: "Partner Program", href: "/partner" },
      { name: "Careers", href: "/careers" },
      { name: "Contact", href: "/contact" }
    ],
    legal: [
      { name: "Privacy Policy", href: "/privacy" },
      { name: "Terms of Service", href: "/terms" }
    ],
    support: [
      { name: "Help Center", href: "/help" },
      { name: "FAQs", href: "#faqs" },
      { name: "Live Chat", href: "#" },
      { name: "Call Support", href: "tel:734-590-3315" }
    ]
  };

  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img 
                src={logoIcon} 
                alt="Free Credit Card Processing" 
                className="w-8 h-8 rounded-md"
              />
              <span className="font-bold text-lg">
                FreeCreditCard<br />Processor.com
              </span>
            </div>
            <p className="text-background/80 leading-relaxed">
              Helping small businesses save money on payment processing with transparent, fee-free solutions.
            </p>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Company</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href}
                    className="text-background/80 hover:text-background transition-smooth"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Legal</h3>
            <ul className="space-y-2">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href}
                    className="text-background/80 hover:text-background transition-smooth"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4">Support</h3>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href}
                    className="text-background/80 hover:text-background transition-smooth"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-background/20 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-background/60 text-sm">
            © 2024 FreeCreditCardProcessor.com. All rights reserved.
          </p>
          
          <div className="flex items-center gap-6">
            <div className="text-sm text-background/60">
              🔒 Bank-level security • PCI DSS compliant
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
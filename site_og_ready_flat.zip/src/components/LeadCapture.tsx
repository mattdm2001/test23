import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Clock, CheckCircle } from "lucide-react";

const LeadCapture = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    businessName: "",
    monthlyVolume: ""
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log("Form submitted:", formData);
  };

  const trustBadges = [
    { icon: <Shield className="w-4 h-4" />, text: "No obligations" },
    { icon: <CheckCircle className="w-4 h-4" />, text: "No credit check" },
    { icon: <Clock className="w-4 h-4" />, text: "2-minute setup" }
  ];

  return (
    <section id="contact" className="py-16 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Ready to Start Saving on Credit Card Fees?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8">
            See if you qualify for free credit card processing in under 2 minutes.
          </p>

          <Card className="p-8 bg-white/95 backdrop-blur-sm shadow-glow">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-foreground font-medium">
                    Full Name *
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="border-border"
                    placeholder="John Smith"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-foreground font-medium">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="border-border"
                    placeholder="john@business.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessName" className="text-foreground font-medium">
                  Business Name *
                </Label>
                <Input
                  id="businessName"
                  name="businessName"
                  type="text"
                  value={formData.businessName}
                  onChange={handleInputChange}
                  required
                  className="border-border"
                  placeholder="Your Business Name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="monthlyVolume" className="text-foreground font-medium">
                  Monthly Card Processing Volume
                </Label>
                <Input
                  id="monthlyVolume"
                  name="monthlyVolume"
                  type="text"
                  value={formData.monthlyVolume}
                  onChange={handleInputChange}
                  className="border-border"
                  placeholder="$5,000"
                />
              </div>

              <Button 
                type="button" 
                variant="cta" 
                size="xl" 
                className="w-full"
                onClick={() => window.location.href = "/onboard"}
              >
                See If You Qualify
              </Button>
            </form>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-6 mt-6 pt-6 border-t border-border">
              {trustBadges.map((badge, index) => (
                <div key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <div className="text-success">
                    {badge.icon}
                  </div>
                  {badge.text}
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default LeadCapture;
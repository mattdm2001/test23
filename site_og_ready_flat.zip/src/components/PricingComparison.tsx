import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Check, X } from "lucide-react";

const PricingComparison = () => {
  const navigate = useNavigate();
  const comparisonData = [
    {
      feature: "Setup Cost",
      us: "$0",
      traditional: "$199+",
      highlight: true
    },
    {
      feature: "Monthly Fee", 
      us: "$0",
      traditional: "$29–$89",
      highlight: true
    },
    {
      feature: "Cancellation Fee",
      us: "$0", 
      traditional: "$295+",
      highlight: true
    },
    {
      feature: "Contract Term",
      us: "Month-to-Month",
      traditional: "2–3 Years",
      highlight: false
    },
    {
      feature: "Equipment",
      us: "Included",
      traditional: "Extra Cost",
      highlight: false
    },
    {
      feature: "24/7 Support",
      us: "✓",
      traditional: "Limited",
      highlight: false
    }
  ];

  return (
    <section className="py-16 bg-gradient-section">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Transparent Pricing
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See exactly how much you'll save compared to traditional payment processors.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden shadow-elegant">
            {/* Desktop Table View */}
            <div className="hidden sm:block">
              <div className="bg-gradient-primary text-primary-foreground">
                <div className="grid grid-cols-3 gap-4 p-4 md:p-6">
                  <div className="text-sm md:text-lg font-semibold">Feature</div>
                  <div className="text-sm md:text-lg font-semibold text-center">
                    FreeCreditCardProcessor.com
                  </div>
                  <div className="text-sm md:text-lg font-semibold text-center">
                    Traditional Processor
                  </div>
                </div>
              </div>

              <div className="divide-y divide-border">
                {comparisonData.map((row, index) => (
                  <div 
                    key={index} 
                    className={`grid grid-cols-3 gap-4 p-3 md:p-4 ${
                      row.highlight ? 'bg-success/5' : 'bg-card'
                    }`}
                  >
                    <div className="font-medium text-foreground flex items-center text-sm md:text-base">
                      {row.feature}
                      {row.highlight && <Check className="w-3 h-3 md:w-4 md:h-4 text-success ml-2" />}
                    </div>
                    
                    <div className="text-center">
                      <span className={`font-bold text-sm md:text-base ${
                        row.highlight ? 'text-success' : 'text-foreground'
                      }`}>
                        {row.us}
                      </span>
                    </div>
                    
                    <div className="text-center">
                      <span className={`font-medium text-sm md:text-base ${
                        row.highlight ? 'text-destructive' : 'text-muted-foreground'
                      }`}>
                        {row.traditional}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mobile Card View */}
            <div className="sm:hidden">
              <div className="bg-gradient-primary text-primary-foreground p-4 text-center">
                <h3 className="text-lg font-bold">Pricing Comparison</h3>
              </div>
              
              <div className="divide-y divide-border">
                {comparisonData.map((row, index) => (
                  <div key={index} className={`p-4 ${row.highlight ? 'bg-success/5' : 'bg-card'}`}>
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-foreground flex items-center">
                        {row.feature}
                        {row.highlight && <Check className="w-4 h-4 text-success ml-2" />}
                      </h4>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-3">
                      <div className="text-center p-3 bg-background rounded-lg border">
                        <div className="text-xs text-muted-foreground mb-1">Our Price</div>
                        <div className={`font-bold ${
                          row.highlight ? 'text-success' : 'text-foreground'
                        }`}>
                          {row.us}
                        </div>
                      </div>
                      
                      <div className="text-center p-3 bg-background rounded-lg border">
                        <div className="text-xs text-muted-foreground mb-1">Traditional</div>
                        <div className={`font-medium ${
                          row.highlight ? 'text-destructive' : 'text-muted-foreground'
                        }`}>
                          {row.traditional}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-primary text-primary-foreground p-6 text-center">
              <h3 className="text-xl font-bold mb-2">
                Average Annual Savings: <span className="text-primary-glow">$1,200+</span>
              </h3>
              <p className="text-primary-foreground/90 mb-4">
                Based on typical small business processing volume
              </p>
              <Button 
                variant="outline" 
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                onClick={() => navigate("/calculator")}
              >
                See How Much You'll Save
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default PricingComparison;
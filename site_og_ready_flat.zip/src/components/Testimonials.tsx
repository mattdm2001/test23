import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      business: "Johnson's Bakery",
      quote: "Finally switched from Square — no more $60/month fees. This saved me over $700 last year alone!",
      rating: 5
    },
    {
      name: "Mike Rodriguez", 
      business: "Rodriguez Auto Repair",
      quote: "Simple, transparent, and fast setup. Had payment processing running in 24 hours with zero upfront costs.",
      rating: 5
    },
    {
      name: "Lisa Chen",
      business: "Chen's Boutique",
      quote: "More cash in my account, period. No hidden fees, no surprises. Just straightforward payment processing.",
      rating: 5
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Business Owners Say
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join thousands of satisfied business owners who've made the switch.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6 hover:shadow-card transition-smooth bg-card border-border">
              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>

              {/* Quote */}
              <blockquote className="text-foreground italic mb-6 leading-relaxed">
                "{testimonial.quote}"
              </blockquote>

              {/* Author */}
              <div className="border-t border-border pt-4">
                <div className="font-semibold text-foreground">
                  {testimonial.name}
                </div>
                <div className="text-sm text-muted-foreground">
                  {testimonial.business}
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Trust indicators */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 bg-success/10 text-success px-4 py-2 rounded-full text-sm font-medium">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            Over 10,000 businesses trust our platform
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQ = () => {
  const faqs = [
    {
      question: "Is it really free?",
      answer: "Yes. You won't pay monthly fees, setup fees, or transaction fees. The processing cost is passed to your customer at checkout via a small service fee, meaning you keep 100% of your sales revenue."
    },
    {
      question: "How is this legal?",
      answer: "Passing on processing fees is legal in most U.S. states. Our processing partners ensure full compliance with all local and federal regulations, including proper signage and fee disclosures."
    },
    {
      question: "What kind of businesses qualify?",
      answer: "Most retail, restaurant, service-based, and online businesses qualify — as long as you process card payments and want to save money."
    },
    {
      question: "Do I need new equipment?",
      answer: "In most cases, no. If your current POS system supports surcharge or cash discount programs, you're good to go. If not, we'll provide you with compliant, modern terminals at no cost."
    },
    {
      question: "How quickly can I get set up?",
      answer: "You can be approved and processing within 24 to 48 hours. It's a fast, streamlined onboarding process."
    },
    {
      question: "Will my customers complain about the service fee?",
      answer: "Very rarely. Most customers are used to small service fees, and our signage ensures full transparency. Many merchants report zero pushback — and they love keeping more of their revenue."
    },
    {
      question: "Can I cancel anytime?",
      answer: "Yes. There are no contracts or cancellation fees. You're not locked in."
    },
    {
      question: "What support is available?",
      answer: "You'll have access to live phone, chat, and email support through our U.S.-based service team. Most support tickets are resolved same-day."
    }
  ];

  return (
    <section id="faq" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible defaultValue="item-0" className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b border-border">
                <AccordionTrigger className="text-left text-lg font-semibold text-foreground hover:text-primary transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-base text-muted-foreground leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Still have questions link */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            Still have questions?{" "}
            <a href="#contact" className="text-primary hover:underline font-medium">
              Contact us
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
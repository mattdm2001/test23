import { useEffect, useRef, useState } from "react";
import SignaturePad from "signature_pad";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RotateCcw } from "lucide-react";

interface SignatureCanvasProps {
  onSignatureChange: (signature: string) => void;
  value?: string;
}

export const SignatureCanvas = ({ onSignatureChange, value }: SignatureCanvasProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const signaturePadRef = useRef<SignaturePad | null>(null);
  const [isEmpty, setIsEmpty] = useState(true);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const signaturePad = new SignaturePad(canvas, {
      backgroundColor: '#ffffff',
      penColor: '#000000',
      minWidth: 1,
      maxWidth: 3,
      throttle: 16,
      minDistance: 5,
    });

    signaturePadRef.current = signaturePad;

    // Handle signature change
    const handleSignatureEnd = () => {
      if (!signaturePad.isEmpty()) {
        setIsEmpty(false);
        const dataURL = signaturePad.toDataURL('image/png');
        onSignatureChange(dataURL);
      }
    };

    signaturePad.addEventListener('endStroke', handleSignatureEnd);

    // Set canvas size
    const resizeCanvas = () => {
      const ratio = Math.max(window.devicePixelRatio || 1, 1);
      canvas.width = 400 * ratio;
      canvas.height = 200 * ratio;
      canvas.style.width = '400px';
      canvas.style.height = '200px';
      canvas.getContext('2d')?.scale(ratio, ratio);
      signaturePad.clear(); // Clear and redraw with proper scaling
    };

    resizeCanvas();

    return () => {
      signaturePad.removeEventListener('endStroke', handleSignatureEnd);
      signaturePad.off();
    };
  }, [onSignatureChange]);

  // Load existing signature if provided
  useEffect(() => {
    if (value && value.startsWith("data:image") && signaturePadRef.current) {
      signaturePadRef.current.fromDataURL(value);
      setIsEmpty(false);
    }
  }, [value]);

  const handleClear = () => {
    if (signaturePadRef.current) {
      signaturePadRef.current.clear();
      setIsEmpty(true);
      onSignatureChange("");
    }
  };

  return (
    <div className="space-y-4">
      <Label>Electronic Signature *</Label>
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
        <div className="flex justify-between items-center mb-2">
          <p className="text-sm text-gray-600">Please sign below:</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="flex items-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Clear
          </Button>
        </div>
        <div className="flex justify-center bg-gray-50 rounded-lg p-2">
          <canvas
            ref={canvasRef}
            className="border-2 border-gray-300 rounded bg-white cursor-crosshair"
            style={{ 
              touchAction: 'none',
              maxWidth: '100%',
              display: 'block'
            }}
          />
        </div>
        <p className="text-xs text-gray-500 mt-2 text-center">
          {isEmpty ? "Click and drag to create your signature (you can sign multiple times)" : "Signature captured - you can add more if needed"}
        </p>
      </div>
    </div>
  );
};
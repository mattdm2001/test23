export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      application_documents: {
        Row: {
          application_id: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          uploaded_at: string
        }
        Insert: {
          application_id?: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          uploaded_at?: string
        }
        Update: {
          application_id?: string | null
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          uploaded_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "application_documents_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "applications"
            referencedColumns: ["id"]
          },
        ]
      }
      applications: {
        Row: {
          average_transaction: number | null
          business_address: string
          business_name: string
          business_type: string | null
          contact_email: string
          contact_name: string
          contact_phone: string
          created_at: string
          current_processor: string | null
          id: string
          monthly_volume: number | null
          signature_data: string
          status: string | null
          terms_accepted: boolean
          updated_at: string
        }
        Insert: {
          average_transaction?: number | null
          business_address: string
          business_name: string
          business_type?: string | null
          contact_email: string
          contact_name: string
          contact_phone: string
          created_at?: string
          current_processor?: string | null
          id?: string
          monthly_volume?: number | null
          signature_data: string
          status?: string | null
          terms_accepted?: boolean
          updated_at?: string
        }
        Update: {
          average_transaction?: number | null
          business_address?: string
          business_name?: string
          business_type?: string | null
          contact_email?: string
          contact_name?: string
          contact_phone?: string
          created_at?: string
          current_processor?: string | null
          id?: string
          monthly_volume?: number | null
          signature_data?: string
          status?: string | null
          terms_accepted?: boolean
          updated_at?: string
        }
        Relationships: []
      }
      calculator_results: {
        Row: {
          created_at: string
          current_spend: number
          email: string | null
          estimated_savings: number
          id: string
          percentage_savings: number
        }
        Insert: {
          created_at?: string
          current_spend: number
          email?: string | null
          estimated_savings: number
          id?: string
          percentage_savings: number
        }
        Update: {
          created_at?: string
          current_spend?: number
          email?: string | null
          estimated_savings?: number
          id?: string
          percentage_savings?: number
        }
        Relationships: []
      }
      calculator_submissions: {
        Row: {
          calculated_annual_fees: number
          calculated_annual_savings: number
          calculated_monthly_fees: number
          calculated_monthly_savings: number
          created_at: string
          email: string
          id: string
          monthly_sales: number
          name: string
          phone: string
          status: string
          updated_at: string
        }
        Insert: {
          calculated_annual_fees: number
          calculated_annual_savings: number
          calculated_monthly_fees: number
          calculated_monthly_savings: number
          created_at?: string
          email: string
          id?: string
          monthly_sales: number
          name: string
          phone: string
          status?: string
          updated_at?: string
        }
        Update: {
          calculated_annual_fees?: number
          calculated_annual_savings?: number
          calculated_monthly_fees?: number
          calculated_monthly_savings?: number
          created_at?: string
          email?: string
          id?: string
          monthly_sales?: number
          name?: string
          phone?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      contact_requests: {
        Row: {
          business_name: string | null
          created_at: string
          email: string
          id: string
          is_current_merchant: string | null
          message: string | null
          name: string
          phone_number: string
          status: string
          updated_at: string
        }
        Insert: {
          business_name?: string | null
          created_at?: string
          email: string
          id?: string
          is_current_merchant?: string | null
          message?: string | null
          name: string
          phone_number: string
          status?: string
          updated_at?: string
        }
        Update: {
          business_name?: string | null
          created_at?: string
          email?: string
          id?: string
          is_current_merchant?: string | null
          message?: string | null
          name?: string
          phone_number?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      contacts: {
        Row: {
          company: string | null
          created_at: string
          email: string
          id: string
          message: string
          name: string
          phone: string | null
        }
        Insert: {
          company?: string | null
          created_at?: string
          email: string
          id?: string
          message: string
          name: string
          phone?: string | null
        }
        Update: {
          company?: string | null
          created_at?: string
          email?: string
          id?: string
          message?: string
          name?: string
          phone?: string | null
        }
        Relationships: []
      }
      onboarding_applications: {
        Row: {
          accepts_tips: string
          account_number: string
          avg_ticket_size: string
          bank_name: string
          business_address: string
          business_license_url: string | null
          business_name: string
          business_phone: string
          business_type: string
          certified: boolean
          created_at: string
          current_pos: string | null
          current_processor: string | null
          date_of_birth: string
          dba: string | null
          drivers_license_url: string | null
          ein: string
          email: string
          home_address: string
          id: string
          mobile_phone: string
          monthly_transactions: string
          monthly_volume: string
          needs_equipment: string | null
          needs_signage: string | null
          owner_name: string
          ownership_percent: string
          physical_location: string
          processing_statement_url: string | null
          routing_number: string
          signature_url: string | null
          ssn: string
          status: string
          submitted_at: string | null
          terminal_type: string | null
          updated_at: string
          user_id: string | null
          website: string | null
        }
        Insert: {
          accepts_tips: string
          account_number: string
          avg_ticket_size: string
          bank_name: string
          business_address: string
          business_license_url?: string | null
          business_name: string
          business_phone: string
          business_type: string
          certified?: boolean
          created_at?: string
          current_pos?: string | null
          current_processor?: string | null
          date_of_birth: string
          dba?: string | null
          drivers_license_url?: string | null
          ein: string
          email: string
          home_address: string
          id?: string
          mobile_phone: string
          monthly_transactions: string
          monthly_volume: string
          needs_equipment?: string | null
          needs_signage?: string | null
          owner_name: string
          ownership_percent: string
          physical_location: string
          processing_statement_url?: string | null
          routing_number: string
          signature_url?: string | null
          ssn: string
          status?: string
          submitted_at?: string | null
          terminal_type?: string | null
          updated_at?: string
          user_id?: string | null
          website?: string | null
        }
        Update: {
          accepts_tips?: string
          account_number?: string
          avg_ticket_size?: string
          bank_name?: string
          business_address?: string
          business_license_url?: string | null
          business_name?: string
          business_phone?: string
          business_type?: string
          certified?: boolean
          created_at?: string
          current_pos?: string | null
          current_processor?: string | null
          date_of_birth?: string
          dba?: string | null
          drivers_license_url?: string | null
          ein?: string
          email?: string
          home_address?: string
          id?: string
          mobile_phone?: string
          monthly_transactions?: string
          monthly_volume?: string
          needs_equipment?: string | null
          needs_signage?: string | null
          owner_name?: string
          ownership_percent?: string
          physical_location?: string
          processing_statement_url?: string | null
          routing_number?: string
          signature_url?: string | null
          ssn?: string
          status?: string
          submitted_at?: string | null
          terminal_type?: string | null
          updated_at?: string
          user_id?: string | null
          website?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const

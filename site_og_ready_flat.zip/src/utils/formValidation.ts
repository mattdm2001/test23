// Form validation utilities for the onboard process

interface FormData {
  // Step 1: Business Basics
  businessName: string;
  businessAddress: string;
  businessPhone: string;
  ein: string;
  
  // Step 2: Ownership Information
  ownerName: string;
  dateOfBirth: string;
  email: string;
  mobilePhone: string;
  ownershipPercent: string;
  homeAddress: string;
  ssn: string;
  
  // Step 3: Business Type & Processing
  businessType: string;
  monthlyVolume: string;
  avgTicketSize: string;
  monthlyTransactions: string;
  acceptsTips: string;
  physicalLocation: string;
  
  // Step 4: Banking Info
  bankName: string;
  routingNumber: string;
  accountNumber: string;
  
  // Step 5: Supporting Documents
  driversLicense: any;
  businessLicense: any;
  processingStatement: any;
  
  // Step 6: Equipment & Setup
  needsEquipment: string;
  
  // Step 7: Certification
  certified: boolean;
  signature: string;
}

const requiredFieldsByStep: Record<number, (keyof FormData)[]> = {
  1: ['businessName', 'businessAddress', 'businessPhone', 'ein'],
  2: ['ownerName', 'dateOfBirth', 'email', 'mobilePhone', 'ownershipPercent', 'homeAddress', 'ssn'],
  3: ['businessType', 'monthlyVolume', 'avgTicketSize', 'monthlyTransactions', 'acceptsTips', 'physicalLocation'],
  4: ['bankName', 'routingNumber', 'accountNumber'],
  5: ['driversLicense'], // Only driver's license is required
  6: ['needsEquipment'],
  7: ['signature'] // certified is handled separately
};

export const validateStep = (step: number, formData: FormData): { isValid: boolean; missingFields: string[] } => {
  const requiredFields = requiredFieldsByStep[step] || [];
  const missingFields: string[] = [];

  for (const field of requiredFields) {
    const value = formData[field];
    
    // Check if field is empty or null
    if (!value || (typeof value === 'string' && value.trim() === '')) {
      missingFields.push(field);
    }
  }

  // Special validation for step 7 (certification)
  if (step === 7) {
    if (!formData.certified) {
      missingFields.push('certified');
    }
  }

  return {
    isValid: missingFields.length === 0,
    missingFields
  };
};

export const getFieldDisplayName = (fieldName: string): string => {
  const displayNames: Record<string, string> = {
    businessName: 'Business Name',
    businessAddress: 'Business Address',
    businessPhone: 'Business Phone',
    ein: 'EIN or SSN',
    ownerName: 'Owner Full Name',
    dateOfBirth: 'Date of Birth',
    email: 'Email Address',
    mobilePhone: 'Mobile Phone',
    ownershipPercent: 'Ownership Percentage',
    homeAddress: 'Home Address',
    ssn: 'SSN (Last 4 digits)',
    businessType: 'Business Type',
    monthlyVolume: 'Monthly Credit Card Volume',
    avgTicketSize: 'Average Ticket Size',
    monthlyTransactions: 'Monthly Transactions',
    acceptsTips: 'Accepts Tips',
    physicalLocation: 'Physical Location',
    bankName: 'Bank Name',
    routingNumber: 'Routing Number',
    accountNumber: 'Account Number',
    driversLicense: "Driver's License",
    businessLicense: 'Business License',
    processingStatement: 'Processing Statement',
    needsEquipment: 'Equipment Needs',
    certified: 'Certification Agreement',
    signature: 'Electronic Signature'
  };

  return displayNames[fieldName] || fieldName;
};
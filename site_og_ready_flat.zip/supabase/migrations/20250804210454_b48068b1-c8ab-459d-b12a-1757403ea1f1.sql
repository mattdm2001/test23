-- Create profiles table for user data
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Create onboarding applications table
CREATE TABLE public.onboarding_applications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  
  -- Step 1: Business Basics
  business_name TEXT NOT NULL,
  dba TEXT,
  business_address TEXT NOT NULL,
  business_phone TEXT NOT NULL,
  website TEXT,
  ein TEXT NOT NULL,
  
  -- Step 2: Ownership Information
  owner_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  email TEXT NOT NULL,
  mobile_phone TEXT NOT NULL,
  ownership_percent TEXT NOT NULL,
  home_address TEXT NOT NULL,
  ssn TEXT NOT NULL,
  
  -- Step 3: Business Type & Processing
  business_type TEXT NOT NULL,
  monthly_volume TEXT NOT NULL,
  avg_ticket_size TEXT NOT NULL,
  monthly_transactions TEXT NOT NULL,
  current_processor TEXT,
  accepts_tips TEXT NOT NULL,
  physical_location TEXT NOT NULL,
  
  -- Step 4: Banking Info
  bank_name TEXT NOT NULL,
  routing_number TEXT NOT NULL,
  account_number TEXT NOT NULL,
  
  -- Step 5: Supporting Documents (file paths)
  drivers_license_url TEXT,
  business_license_url TEXT,
  processing_statement_url TEXT,
  
  -- Step 6: Equipment & Setup
  needs_equipment TEXT,
  terminal_type TEXT,
  current_pos TEXT,
  needs_signage TEXT,
  
  -- Step 7: Certification
  certified BOOLEAN NOT NULL DEFAULT false,
  signature_url TEXT,
  
  -- Application status
  status TEXT NOT NULL DEFAULT 'pending',
  submitted_at TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on onboarding applications
ALTER TABLE public.onboarding_applications ENABLE ROW LEVEL SECURITY;

-- Create policies for onboarding applications
CREATE POLICY "Users can view their own applications" 
ON public.onboarding_applications 
FOR SELECT 
USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can create applications" 
ON public.onboarding_applications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can update their own applications" 
ON public.onboarding_applications 
FOR UPDATE 
USING (auth.uid() = user_id OR user_id IS NULL);

-- Create contact requests table
CREATE TABLE public.contact_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  business_name TEXT,
  phone_number TEXT NOT NULL,
  email TEXT NOT NULL,
  is_current_merchant TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on contact requests
ALTER TABLE public.contact_requests ENABLE ROW LEVEL SECURITY;

-- Create policies for contact requests (public submission)
CREATE POLICY "Anyone can create contact requests" 
ON public.contact_requests 
FOR INSERT 
WITH CHECK (true);

-- Create calculator submissions table
CREATE TABLE public.calculator_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  monthly_sales DECIMAL(12,2) NOT NULL,
  calculated_monthly_fees DECIMAL(10,2) NOT NULL,
  calculated_annual_fees DECIMAL(10,2) NOT NULL,
  calculated_monthly_savings DECIMAL(10,2) NOT NULL,
  calculated_annual_savings DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on calculator submissions
ALTER TABLE public.calculator_submissions ENABLE ROW LEVEL SECURITY;

-- Create policies for calculator submissions (public submission)
CREATE POLICY "Anyone can create calculator submissions" 
ON public.calculator_submissions 
FOR INSERT 
WITH CHECK (true);

-- Create storage buckets for file uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);

-- Create storage policies for document uploads
CREATE POLICY "Users can upload their own documents" 
ON storage.objects 
FOR INSERT 
WITH CHECK (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own documents" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own documents" 
ON storage.objects 
FOR UPDATE 
USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own documents" 
ON storage.objects 
FOR DELETE 
USING (bucket_id = 'documents' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_onboarding_applications_updated_at
  BEFORE UPDATE ON public.onboarding_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contact_requests_updated_at
  BEFORE UPDATE ON public.contact_requests
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_calculator_submissions_updated_at
  BEFORE UPDATE ON public.calculator_submissions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();